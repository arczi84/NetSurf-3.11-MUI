/*
 * Copyright 2009 Ilkka Lehtoranta <ilkleht@isoveli.org>
 *
 * This file is part of NetSurf, http://www.netsurf-browser.org/
 *
 * NetSurf is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; version 2 of the License.
 *
 * NetSurf is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <stddef.h>

#include <proto/exec.h>

#include "mui/bitmap.h"
#include "mui/font.h"
#include "mui/mui.h"

// Dodaj na początku pliku
#include "utils/log.h"

#define SCH_LOG LOG
#define SCH_LOG2

STATIC struct MinList schedule_list =
{
	(APTR)&schedule_list.mlh_Tail,
	NULL,
	(APTR)&schedule_list.mlh_Head
};

STATIC struct MsgPort *msgport;
STATIC struct timerequest tioreq;
STATIC UBYTE got_timer_device;

ULONG schedule_sig;

struct nscallback
{
	struct MinNode node;
	struct timerequest treq;
	void (*callback)(void *p);
	void *p;
};

bool mui_schedule_has_tasks(void)
{
    // Sprawdź czy lista scheduled tasks nie jest pusta
    return !ISLISTEMPTY(&schedule_list);  // Jeśli masz listę
    
    // LUB sprawdź czy są pending messages:
    return (bool)CheckMsg(msgport);
}

static void remove_timer_event(struct nscallback *nscb)
{
	SCH_LOG2(("remove_timer_event: START - nscb=%p", nscb));
	
	if (!nscb) {
		SCH_LOG2(("remove_timer_event: ERROR - nscb is NULL"));
		return;
	}
	
	SCH_LOG2(("remove_timer_event: Calling AbortIO"));
	AbortIO((struct IORequest *)&nscb->treq);
	
	SCH_LOG2(("remove_timer_event: Calling REMOVE"));
	REMOVE(nscb);
	
	SCH_LOG2(("remove_timer_event: Calling WaitIO"));
	WaitIO((struct IORequest *)&nscb->treq);
	
	SCH_LOG2(("remove_timer_event: Calling FreeMem"));
	FreeMem(nscb, sizeof(*nscb));
	
	SCH_LOG2(("remove_timer_event: END"));
}

/**
 * Schedule a callback.
 *
 * \param  t         interval before the callback should be made / cs
 * \param  callback  callback function
 * \param  p         user parameter, passed to callback function
 *
 * The callback function will be called as soon as possible after t cs have
 * passed.
 */

void mui_schedule(int t, void (*callback)(void *p), void *p)
{
	struct nscallback *nscb;

	SCH_LOG2(("mui_schedule: START - t=%d, callback=%p, p=%p", t, callback, p));

	if (!callback) {
		SCH_LOG2(("mui_schedule: ERROR - callback is NULL"));
		return;
	}

	if (!msgport) {
		SCH_LOG2(("mui_schedule: ERROR - msgport is NULL"));
		return;
	}

	if (!got_timer_device) {
		SCH_LOG2(("mui_schedule: ERROR - timer device not available"));
		return;
	}

	SCH_LOG2(("mui_schedule: Calling AllocMem"));
	nscb = AllocMem(sizeof(*nscb), MEMF_ANY);

	if (nscb) {
		SCH_LOG2(("mui_schedule: AllocMem success - nscb=%p", nscb));
		
		// Zmieniono na UNIT_VBLANK
		//t = (t + 1) / 2; // zaokrąglij w górę do najbliższego 1/50s
		t *= 10000; // 1/50s = 20000 mikrosekund
		
		SCH_LOG2(("mui_schedule: Converted time t=%d microseconds", t));

		nscb->callback = callback;
		nscb->p = p;

		SCH_LOG2(("mui_schedule: Setting up timer request"));
		nscb->treq.tr_node.io_Message.mn_ReplyPort =
				tioreq.tr_node.io_Message.mn_ReplyPort;
		nscb->treq.tr_node.io_Device  = tioreq.tr_node.io_Device;
		nscb->treq.tr_node.io_Unit    = tioreq.tr_node.io_Unit;
		nscb->treq.tr_node.io_Command = TR_ADDREQUEST;
		nscb->treq.tr_time.tv_secs  = t / 1000000;
		nscb->treq.tr_time.tv_micro = t % 1000000;

		SCH_LOG2(("mui_schedule: Timer set for %d secs, %d microsecs", 
		     nscb->treq.tr_time.tv_secs, nscb->treq.tr_time.tv_micro));

		SCH_LOG2(("mui_schedule: Calling SendIO"));
  		SendIO((struct IORequest *)&nscb->treq);

		SCH_LOG2(("mui_schedule: Calling ADDTAIL"));
		ADDTAIL(&schedule_list, nscb);
		
		SCH_LOG2(("mui_schedule: SUCCESS - timer scheduled"));
	} else {
		SCH_LOG2(("mui_schedule: ERROR - AllocMem failed"));
	}
	
	//SCH_LOG(("mui_schedule: END"));
	 Delay(1); 
}

/**
 * Unschedule a callback.
 *
 * \param  callback  callback function
 * \param  p         user parameter, passed to callback function
 *
 * All scheduled callbacks matching both callback and p are removed.
 */

void schedule_remove(void (*callback)(void *p), void *p)
{
	struct nscallback *nscb, *next;

	SCH_LOG2(("schedule_remove: START - callback=%p, p=%p", callback, p));

	ITERATELISTSAFE(nscb, next, &schedule_list) {
		SCH_LOG2(("schedule_remove: Checking nscb=%p (callback=%p, p=%p)", 
		     nscb, nscb->callback, nscb->p));
		     
		if ((nscb->callback == callback) && (nscb->p == p)) {
			SCH_LOG2(("schedule_remove: Found matching callback - removing"));
			remove_timer_event(nscb);
		}
	}
	
	SCH_LOG2(("schedule_remove: END"));
}

static void schedule_add_cache_timer(struct timerequest *req)
{
	SCH_LOG2(("schedule_add_cache_timer: START"));
	
	if (!req) {
		SCH_LOG2(("schedule_add_cache_timer: ERROR - req is NULL"));
		return;
	}
	
	req->tr_node.io_Command = TR_ADDREQUEST;
	req->tr_time.tv_secs  = 5 * 60;
	req->tr_time.tv_micro = 0;
	
	SCH_LOG2(("schedule_add_cache_timer: Calling SendIO"));
	SendIO((struct IORequest *)req);
	
	SCH_LOG2(("schedule_add_cache_timer: END"));
}

/**
 * Poll events
 *
 * Process events up to current time.
 */

VOID mui_schedule_poll(void)
{
	APTR msg;

	SCH_LOG2(("mui_schedule_poll: START"));

	if (!msgport) {
		SCH_LOG2(("mui_schedule_poll: ERROR - msgport is NULL"));
		return;
	}

	while ((msg = GetMsg(msgport))) {
		SCH_LOG2(("mui_schedule_poll: Got message %p", msg));
		
		if (msg == &tioreq.tr_node.io_Message) {
			SCH_LOG2(("mui_schedule_poll: Cache timer message"));
			
			SCH_LOG2(("mui_schedule_poll: Calling bitmap_cache_check"));
			bitmap_cache_check();
			
			SCH_LOG2(("mui_schedule_poll: Calling font_cache_check"));
			font_cache_check();
			
			SCH_LOG2(("mui_schedule_poll: Rescheduling cache timer"));
			schedule_add_cache_timer(msg);
		} else {
			struct nscallback *nscb = (APTR)((IPTR)msg -
					offsetof(struct nscallback, treq));
					
			SCH_LOG2(("mui_schedule_poll: Callback message - nscb=%p, callback=%p, p=%p", 
			     nscb, nscb->callback, nscb->p));
			     
			if (nscb->callback) {
				SCH_LOG2(("mui_schedule_poll: Calling callback"));
				nscb->callback(nscb->p);
				SCH_LOG2(("mui_schedule_poll: Callback returned"));
			} else {
				SCH_LOG2(("mui_schedule_poll: ERROR - callback is NULL"));
			}
			
			SCH_LOG2(("mui_schedule_poll: Removing from list"));
			REMOVE(nscb);
			
			SCH_LOG2(("mui_schedule_poll: Freeing memory"));
			FreeMem(nscb, sizeof(*nscb));
		}
	}
	
	SCH_LOG2(("mui_schedule_poll: END"));
}

/**
 * Initialise
 */

BOOL mui_schedule_init(void)
{
	BOOL rc;

	SCH_LOG2(("mui_schedule_init: START"));

	msgport = CreateMsgPort();
	rc = FALSE;

	if (msgport) {
		SCH_LOG2(("mui_schedule_init: MsgPort created successfully"));
		
		tioreq.tr_node.io_Message.mn_ReplyPort = msgport;

		/* UNIT_VBLANK is very cheap but has low resolution (1/50s)
		 *
		 * UNIT_MICROHZ has better accuracy but costs more
		 */

		SCH_LOG2(("mui_schedule_init: Opening timer.device with UNIT_VBLANK"));
		if (OpenDevice("timer.device", UNIT_VBLANK, &tioreq.tr_node, 0) == 0) {
			SCH_LOG2(("mui_schedule_init: Timer device opened successfully"));
			
			got_timer_device = 1;
			schedule_sig = 1 << msgport->mp_SigBit;
			rc = TRUE;

			SCH_LOG2(("mui_schedule_init: Adding initial cache timer"));
			schedule_add_cache_timer(&tioreq);
		} else {
			SCH_LOG2(("mui_schedule_init: ERROR - Failed to open timer.device"));
		}
	} else {
		SCH_LOG2(("mui_schedule_init: ERROR - Failed to create MsgPort"));
	}

	SCH_LOG2(("mui_schedule_init: END - returning %s", rc ? "TRUE" : "FALSE"));
	return rc;
}

/**
 * Abort all events and quit
 */

void mui_schedule_finalise(void)
{
	SCH_LOG2(("mui_schedule_finalise: START"));

	if (got_timer_device) {
		struct nscallback *nscb, *next;

		SCH_LOG2(("mui_schedule_finalise: Removing all scheduled events"));
		ITERATELISTSAFE(nscb, next, &schedule_list) {
			SCH_LOG2(("mui_schedule_finalise: Removing event nscb=%p", nscb));
			remove_timer_event(nscb);
		}

		SCH_LOG2(("mui_schedule_finalise: Aborting main timer"));
		AbortIO((struct IORequest *)&tioreq);
		
		SCH_LOG2(("mui_schedule_finalise: Waiting for main timer"));
		WaitIO((struct IORequest *)&tioreq);
		
		SCH_LOG2(("mui_schedule_finalise: Closing timer device"));
		CloseDevice(&tioreq.tr_node);
	}

	if (msgport) {
		SCH_LOG2(("mui_schedule_finalise: Deleting MsgPort"));
		DeleteMsgPort(msgport);
	}
	
	SCH_LOG2(("mui_schedule_finalise: END"));
}
