
/*
 * config.h
 */

#define __SUPPORTS_PRAGMAS__ 1
