/* Enhanced color handling functions for MUI plotters */
/* Lepsze debugowanie kolorów */
static ULONG ConvertNetSurfColor(colour ns)
{
    ULONG result = ABGR_TO_ARGB(ns & 0x00FFFFFF);
    
    /* Debug log dla sprawdzenia konwersji kolorów */
    LOG(("ConvertNetSurfColor: input=0x%08lX, output=0x%08lX (R=%d G=%d B=%d)", 
         ns, result, 
         (result >> 16) & 0xFF, 
         (result >> 8) & 0xFF, 
         result & 0xFF));
    
    return result;
}

/* Alternatywna funkcja dla RTG bez konwersji */
static ULONG GetDirectPixel(colour ns)
{
    /* NetSurf używa formatu ABGR, RTG oczekuje RGB */
    UBYTE a = (ns >> 24) & 0xFF;
    UBYTE b = (ns >> 16) & 0xFF; 
    UBYTE g = (ns >> 8) & 0xFF;
    UBYTE r = ns & 0xFF;
    
    /* Zwróć w formacie RGB dla CyberGraphX */
    return (r << 16) | (g << 8) | b;
}

/* Initialize pen allocation */
bool InitializePens(void)
{
    if (!renderinfo.screen || !renderinfo.screen->ViewPort.ColorMap) {
        global_pen_a = 1;
        global_pen_b = 0;
        return true;
    }
    
    struct ColorMap *cm = renderinfo.screen->ViewPort.ColorMap;
    if (global_pen_a < 0) {
        global_pen_a = ObtainPen(cm, -1, 0, 0, 0, PEN_EXCLUSIVE);
    }
    if (global_pen_b < 0) {
        global_pen_b = ObtainPen(cm, -1, 0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF, PEN_EXCLUSIVE);
    }
    
    if (global_pen_a < 0) global_pen_a = 1;
    if (global_pen_b < 0) global_pen_b = 0;
    
    return true;
}

/* Enhanced color setting with proper RGB handling */
static VOID SetRGBColor(struct RastPort *rp, ULONG rgb_color, BOOL is_background)
{
    if (!rp) return;
    
    UBYTE r = (rgb_color >> 16) & 0xFF;
    UBYTE g = (rgb_color >> 8) & 0xFF;
    UBYTE b = rgb_color & 0xFF;
    
    /* Cache check to avoid unnecessary pen operations */
    ULONG *last_color = is_background ? &last_bg_color : &last_fg_color;
    if (*last_color == rgb_color) {
        return; /* Color already set */
    }
    *last_color = rgb_color;
    
    struct ViewPort *vp = renderinfo.screen ? &renderinfo.screen->ViewPort : NULL;
    ULONG depth = GetBitMapAttr(rp->BitMap, BMA_DEPTH);
    
    /* For high color RTG screens, try direct pixel manipulation */
    if (depth >= 15 && CyberGfxBase && vp && vp->ColorMap) {
        ULONG r32 = (ULONG)r << 24;
        ULONG g32 = (ULONG)g << 24;
        ULONG b32 = (ULONG)b << 24;
        
        /* Get temporary pen for this specific color */
        LONG pen = ObtainBestPen(vp->ColorMap,
                                 r32, g32, b32,
                                 OBP_Precision, PRECISION_GUI,
                                 TAG_DONE);
        
        if (pen >= 0) {
            if (is_background) {
                SetBPen(rp, pen);
            } else {
                SetAPen(rp, pen);
            }
            /* Don't release pen immediately - keep it for this draw operation */
            return;
        }
    }
    
    /* Fallback for palette modes or when ObtainBestPen fails */
    LONG pen;
    if (vp && vp->ColorMap) {
        ULONG r32 = (ULONG)r << 24;
        ULONG g32 = (ULONG)g << 24;  
        ULONG b32 = (ULONG)b << 24;
        
        pen = ObtainBestPen(vp->ColorMap,
                           r32, g32, b32,
                           OBP_Precision, PRECISION_IMAGE,
                           TAG_DONE);
        
        if (pen < 0) {
            /* Ultimate fallback - use simple color logic */
            ULONG intensity = (r + g + b);
            pen = (intensity > 384) ? 1 : 0;  /* White or black */
        }
    } else {
        /* No viewport - use basic pen selection */
        ULONG intensity = (r + g + b);
        pen = (intensity > 384) ? 1 : 0;
    }
    
    if (is_background) {
        SetBPen(rp, pen);
    } else {
        SetAPen(rp, pen);
    }
}

/* Enhanced rectangle function with direct pixel support */
nserror
mui_rectangle(const struct redraw_context *ctx,
              const plot_style_t *style,
              const struct rect *rect)
{
    struct RastPort *rp = (struct RastPort *)ctx->priv;
    if (!rp) return NSERROR_INVALID;

    /* Handle fill (background) */
    if (style->fill_type != PLOT_OP_TYPE_NONE) {
        ULONG pixel = ConvertNetSurfColor(style->fill_colour);
        ULONG depth = GetBitMapAttr(rp->BitMap, BMA_DEPTH);
        
        /* For RTG screens, try direct pixel writing first */
        if (depth >= 15 && CyberGfxBase) {
            LONG result = FillPixelArray(rp, rect->x0, rect->y0, 
                                        rect->x1 - rect->x0, rect->y1 - rect->y0, pixel);
            
            if (result != -1) {
                /* Direct pixel write successful */
                goto handle_stroke;
            }
            /* If FillPixelArray failed, fall through to pen method */
        }
        
        /* Pen-based filling for palette modes or RTG fallback */
        SetRGBColor(rp, pixel, FALSE);
        RectFill(rp, rect->x0, rect->y0, rect->x1 - 1, rect->y1 - 1);
    }

handle_stroke:
    /* Handle stroke (border) */
    if (style->stroke_type != PLOT_OP_TYPE_NONE) {
        LONG oldPenWidth = rp->PenWidth;
        LONG oldPenHeight = rp->PenHeight;
        UWORD oldLinePtrn = rp->LinePtrn;
        
        rp->PenWidth = MAX(1, plot_style_fixed_to_int(style->stroke_width));
        rp->PenHeight = MAX(1, plot_style_fixed_to_int(style->stroke_width));

        switch (style->stroke_type) {
            case PLOT_OP_TYPE_SOLID:
            default:
                rp->LinePtrn = PATT_LINE;
                break;
            case PLOT_OP_TYPE_DOT:
                rp->LinePtrn = PATT_DOT;
                break;
            case PLOT_OP_TYPE_DASH:
                rp->LinePtrn = PATT_DASH;
                break;
        }

        ULONG pixel = ConvertNetSurfColor(style->stroke_colour);
        SetRGBColor(rp, pixel, FALSE);
        
        Move(rp, rect->x0, rect->y0);
        Draw(rp, rect->x1 - 1, rect->y0);
        Draw(rp, rect->x1 - 1, rect->y1 - 1);
        Draw(rp, rect->x0, rect->y1 - 1);
        Draw(rp, rect->x0, rect->y0);

        /* Restore pen settings */
        rp->PenWidth = oldPenWidth;
        rp->PenHeight = oldPenHeight;
        rp->LinePtrn = oldLinePtrn;
    }

    return NSERROR_OK;
}

/* Enhanced text function with background color support */
nserror
mui_text(const struct redraw_context *ctx,
         const struct plot_font_style *fstyle,
         int x,
         int y,
         const char *text,
         size_t length)
{
    struct RastPort *rp = (struct RastPort *)ctx->priv;
    if (!rp || !text || length == 0) return NSERROR_OK;
    
    /* Open appropriate font */
    APTR font_node = mui_open_font(rp, fstyle);
    if (!font_node) {
        LOG(("WARNING: No font available, using default"));
        /* Fallback rendering with color support */
        ULONG pixel = ConvertNetSurfColor(fstyle->foreground);
        SetRGBColor(rp, pixel, FALSE);
        
        /* Handle background color if specified */
        if (fstyle->background != NS_TRANSPARENT) {
            ULONG bg_pixel = ConvertNetSurfColor(fstyle->background);
            SetRGBColor(rp, bg_pixel, TRUE);
            SetDrMd(rp, JAM2); /* Use both foreground and background */
        } else {
            SetDrMd(rp, JAM1); /* Use only foreground */
        }
        
        int baseline_y = y + (rp->Font ? rp->Font->tf_Baseline : 12) - 13;
        Move(rp, x, baseline_y);
        Text(rp, text, length);
        
        SetDrMd(rp, JAM1); /* Reset to default */
        return NSERROR_OK;
    }
    
    struct fontnode *node = (struct fontnode *)font_node;
    UBYTE oldDm = GetDrMd(rp);
    
    /* Set up drawing mode based on background */
    if (fstyle->background != NS_TRANSPARENT) {
        ULONG bg_pixel = ConvertNetSurfColor(fstyle->background);
        SetRGBColor(rp, bg_pixel, TRUE);
        SetDrMd(rp, JAM2); /* Use both foreground and background */
    } else {
        SetDrMd(rp, JAM1); /* Use only foreground */
    }
    
    /* Set foreground color */
    ULONG pixel = ConvertNetSurfColor(fstyle->foreground);
    SetRGBColor(rp, pixel, FALSE);
    
    bool ok = false;
    
    /* Try system font rendering */
    if (!ok && node->sysfont) {
        const char *render_text = text;
        char *converted_text = NULL;
        size_t render_length = length;
        
        /* Convert UTF-8 if needed */
        if (needs_character_conversion()) {
            converted_text = AllocVec(length * 2 + 1, MEMF_ANY);
            if (converted_text) {
                render_length = convert_utf8_to_iso8859_2(text, length, 
                                                         converted_text, length * 2 + 1);
                render_text = converted_text;
            }
        }
        
        int baseline_y = y + node->sysfont->tf_Baseline - 11;
        Move(rp, x, baseline_y);
        Text(rp, render_text, render_length);
        
        if (converted_text) {
            FreeVec(converted_text);
        }
        ok = true;
    }
    
    /* Fallback to default font */
    if (!ok && rp->Font) {
        int baseline_y = y + rp->Font->tf_Baseline - 13;
        Move(rp, x, baseline_y);
        Text(rp, text, length);
        ok = true;
    }
    
    /* Restore drawing mode */
    SetDrMd(rp, oldDm);
    
    /* Close font */
    mui_close_font(rp, font_node);
    
    return ok ? NSERROR_OK : NSERROR_INVALID;
}

/* Add initialization function to be called at startup */
nserror mui_plotters_init(void)
{
    /* Initialize global variables */
    last_fg_color = 0xFFFFFFFF;
    last_bg_color = 0xFFFFFFFF;
    global_pen_a = -1;
    global_pen_b = -1;
    
    /* Initialize pens */
    InitializePens();
    
    return NSERROR_OK;
}

/* Cleanup function */
void mui_plotters_fini(void)
{
    if (renderinfo.screen && renderinfo.screen->ViewPort.ColorMap) {
        struct ColorMap *cm = renderinfo.screen->ViewPort.ColorMap;
        if (global_pen_a >= 0) {
            ReleasePen(cm, global_pen_a);
            global_pen_a = -1;
        }
        if (global_pen_b >= 0) {
            ReleasePen(cm, global_pen_b);
            global_pen_b = -1;
        }
    }
}
