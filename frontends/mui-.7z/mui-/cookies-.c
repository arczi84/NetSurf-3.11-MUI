/*****************************
 * cookies.c for MUI AmigaOS3
 * Updated for NetSurf 3.11
 * ***************************/

/*
 * Copyright 2008 Chris Young <chris@unsatisfactorysoftware.co.uk>
 *
 * This file is part of NetSurf, http://www.netsurf-browser.org/
 *
 * NetSurf is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; version 2 of the License.
 *
 * NetSurf is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include <proto/exec.h>
#include <proto/intuition.h>
#include <proto/muimaster.h>
#include <proto/utility.h>

#include "utils/log.h"
#include "utils/messages.h"
#include "utils/nsurl.h"
#include "utils/utils.h"

#include "netsurf/browser_window.h"
#include "netsurf/cookie_db.h"
#include "netsurf/mouse.h"
#include "desktop/treeview.h"

#include "mui/gui.h"

#include "mui/cookies.h"

static struct treeview *cookies_tree;

static nserror cookies_redraw_request(int x, int y, int width, int height, void *p)
{
	/* MUI redraw implementation */
	return NSERROR_OK;
}

static void cookies_resized(struct treeview *tree, int width, int height, void *p)
{
	/* MUI resize implementation */
}

static void cookies_scroll_visible(int y, int height, void *p)
{
	/* MUI scroll implementation */
}

static void cookies_get_window_dimensions(int *width, int *height, void *p)
{
	/* MUI dimensions implementation */
	*width = 0;
	*height = 0;
}

static const struct treeview_callback_table cookies_cbs = {
	.folder = NULL,
	.entry = NULL
};

/* Declare field names as lwc_string pointers */
static lwc_string *cookies_field_domain;
static lwc_string *cookies_field_name;
static lwc_string *cookies_field_path;
static lwc_string *cookies_field_content;
static lwc_string *cookies_field_expires;
static lwc_string *cookies_field_secure;
static lwc_string *cookies_field_httponly;

static struct treeview_field_desc cookies_fields[] = {
	{ NULL, TREE_FLAG_SHOW_NAME | TREE_FLAG_DEFAULT },              /* Domain (main field) */
	{ NULL, TREE_FLAG_SHOW_NAME | TREE_FLAG_COPY_TEXT },            /* Name */
	{ NULL, TREE_FLAG_SHOW_NAME | TREE_FLAG_COPY_TEXT },            /* Path */
	{ NULL, TREE_FLAG_SHOW_NAME | TREE_FLAG_COPY_TEXT },            /* Content */
	{ NULL, TREE_FLAG_SHOW_NAME },                                  /* Expires */
	{ NULL, TREE_FLAG_SHOW_NAME },                                  /* Secure */
	{ NULL, TREE_FLAG_SHOW_NAME | TREE_FLAG_DEFAULT }               /* HttpOnly (folder field) */
};

static nserror cookies_add_from_data(const struct nsurl *url, const struct cookie_data *data);
static void cookies_update(const struct nsurl *url, const struct cookie_data *data);

void mui_cookies_initialise(void)
{
	nserror ret;
	
	/* Initialize field name strings */
	lwc_intern_string("Domain", 6, &cookies_field_domain);
	lwc_intern_string("Name", 4, &cookies_field_name);
	lwc_intern_string("Path", 4, &cookies_field_path);
	lwc_intern_string("Content", 7, &cookies_field_content);
	lwc_intern_string("Expires", 7, &cookies_field_expires);
	lwc_intern_string("Secure", 6, &cookies_field_secure);
	lwc_intern_string("HttpOnly", 8, &cookies_field_httponly);
	
	/* Assign field names to descriptors */
	cookies_fields[0].field = cookies_field_domain;
	cookies_fields[1].field = cookies_field_name;
	cookies_fields[2].field = cookies_field_path;
	cookies_fields[3].field = cookies_field_content;
	cookies_fields[4].field = cookies_field_expires;
	cookies_fields[5].field = cookies_field_secure;
	cookies_fields[6].field = cookies_field_httponly;

	/* Create treeview with correct parameters */
	ret = treeview_create(&cookies_tree, &cookies_cbs, 7, cookies_fields, 
			      NULL, NULL, TREEVIEW_DEL_EMPTY_DIRS);
	if (ret != NSERROR_OK) {
		LOG(("Treeview create failed with error %d", ret));
		warn_user("TreeviewInit", 0);
		return;
	}

	urldb_iterate_cookies(cookies_add_from_data);
}

static nserror cookies_add_from_data(const struct nsurl *url, const struct cookie_data *data)
{
	cookies_update(url, data);
	return NSERROR_OK;
}

bool mui_cookies_find(void)
{
	return (cookies_tree != NULL);
}

static void cookies_update(const struct nsurl *url, const struct cookie_data *data)
{
	struct treeview_node *root = treeview_get_root(cookies_tree);
	struct treeview_node *domain_node = NULL;
	struct treeview_node *cookie_node = NULL;
	struct treeview_node *node;

	char expires_buf[32];
	const char *expires_str;

	if (data->expires == -1) {
		expires_str = messages_get("CookieSession");
	} else {
		struct tm *tm = localtime(&data->expires);
		strftime(expires_buf, sizeof(expires_buf), "%Y-%m-%d %H:%M:%S", tm);
		expires_str = expires_buf;
	}

	const char *secure_str = messages_get(data->secure ? "Yes" : "No");
	const char *http_only_str = messages_get(data->http_only ? "Yes" : "No");

	/* Create field data array with proper structure */
	struct treeview_field_data entry[7] = {
		{ .field = cookies_field_domain, .value = data->domain, .value_len = strlen(data->domain) },
		{ .field = cookies_field_name, .value = data->name, .value_len = strlen(data->name) },
		{ .field = cookies_field_path, .value = data->path, .value_len = strlen(data->path) },
		{ .field = cookies_field_content, .value = data->value, .value_len = strlen(data->value) },
		{ .field = cookies_field_expires, .value = expires_str, .value_len = strlen(expires_str) },
		{ .field = cookies_field_secure, .value = secure_str, .value_len = strlen(secure_str) },
		{ .field = cookies_field_httponly, .value = http_only_str, .value_len = strlen(http_only_str) }
	};

	/* Create domain field data */
	struct treeview_field_data domain_field = {
		.field = cookies_field_domain,
		.value = data->domain,
		.value_len = strlen(data->domain)
	};

	/* Find or create domain node */
	node = treeview_node_get_child(root);
	while (node != NULL) {
		const char *text = treeview_node_get_text(node);
		if (text && strcasecmp(text, data->domain) == 0) {
			domain_node = node;
			break;
		}
		node = treeview_node_get_next(node);
	}

	if (domain_node == NULL) {
		nserror ret = treeview_create_node_folder(cookies_tree, &domain_node, root, 
				TREE_REL_FIRST_CHILD, &domain_field, NULL, TREE_OPTION_NONE);
		if (ret != NSERROR_OK) return;
	}

	/* Find existing cookie node */
	node = treeview_node_get_child(domain_node);
	while (node != NULL) {
		const char *text = treeview_node_get_text(node);
		if (text && strcmp(text, data->name) == 0) {
			cookie_node = node;
			break;
		}
		node = treeview_node_get_next(node);
	}

	if (cookie_node != NULL) {
		/* Update existing cookie */
		treeview_update_node_entry(cookies_tree, cookie_node, entry, NULL);
	} else {
		/* Create new cookie entry */
		nserror ret = treeview_create_node_entry(cookies_tree, &cookie_node, domain_node, 
				TREE_REL_FIRST_CHILD, entry, NULL, TREE_OPTION_NONE);
		if (ret != NSERROR_OK) return;
	}
}

void mui_cookies_finalise(void)
{
	if (cookies_tree != NULL) {
		treeview_destroy(cookies_tree);
		cookies_tree = NULL;
	}
	
	/* Clean up field name strings */
	if (cookies_field_domain) lwc_string_unref(cookies_field_domain);
	if (cookies_field_name) lwc_string_unref(cookies_field_name);
	if (cookies_field_path) lwc_string_unref(cookies_field_path);
	if (cookies_field_content) lwc_string_unref(cookies_field_content);
	if (cookies_field_expires) lwc_string_unref(cookies_field_expires);
	if (cookies_field_secure) lwc_string_unref(cookies_field_secure);
	if (cookies_field_httponly) lwc_string_unref(cookies_field_httponly);
}