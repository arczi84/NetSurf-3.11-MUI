/*
 * Copyright 2009 Ilkka Lehtoranta <ilkleht@isoveli.org>
 *
 * This file is part of NetSurf, http://www.netsurf-browser.org/
 *
 * NetSurf is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; version 2 of the License.
 *
 * NetSurf is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <string.h>
#include <stdbool.h>

#include <cybergraphx/cybergraphics.h>
#include <exec/execbase.h>
#include <exec/resident.h>
//#include <exec/system.h> //Only on MorphOS 
#include <intuition/pointerclass.h>
#include <workbench/startup.h>
#include <proto/asyncio.h>
#include <proto/codesets.h>
#include <proto/cybergraphics.h>
#include <proto/dos.h>
#include <proto/exec.h>
#include <proto/graphics.h>
#include <proto/icon.h>
#include <proto/intuition.h>
#include <proto/layers.h>
#include <proto/locale.h>
#include <proto/openurl.h>
#include <proto/ttengine.h>
#include <proto/utility.h>
#include <proto/keymap.h>
#include <proto/diskfont.h>
//nsamiga
#include <proto/guigfx.h>
#include <proto/picasso96api.h>
#include <proto/datatypes.h>
//nsamiga
#ifdef WITH_HUBBUB
#include <hubbub/hubbub.h>
#endif

#include "netsurf/types.h"
#include "content/urldb.h"

#include "desktop/gui_internal.h"
#include "netsurf/browser_window.h"
#include "desktop/browser_private.h"  // For browser_window structure
#include "desktop/selection.h"
#include "desktop/textinput.h"
///////added
#include "utils/errors.h"
#include "netsurf/browser.h"
#include "netsurf/browser_window.h"
#include "desktop/browser_history.h"
#include "netsurf/clipboard.h"
#include "netsurf/download.h"
#include "desktop/download.h"
#include "desktop/gui_table.h"
#include "netsurf/utf8.h"
#include "netsurf/mouse.h"
#include "netsurf/plotters.h"
#include "netsurf/netsurf.h"
#include "netsurf/window.h"
#include "netsurf/misc.h"
#include "netsurf/content.h"

#include "utils/nsoption.h"
#include "content/content.h"
#include "content/hlcache.h"
#include "content/backing_store.h"
///////
#include "mui/applicationclass.h"
#include "mui/bitmap.h"
#include "mui/clipboard.h"
#include "mui/cookies.h"
//#include "mui/fetch_file.h"
#include "mui/fetch.h"
#include "mui/findfile.h"
#include "mui/font.h"
#include "mui/gui.h"
#include "mui/history.h"
#include "mui/methodstack.h"
#include "mui/mui.h"
#include "mui/netsurf.h"
//#include "mui/options.h"
#include "mui/plotters.h"
#include "mui/save_complete.h"
#include "mui/schedule.h"
#include "mui/transferanimclass.h"
#include "mui/utils.h"
#include "html/form_internal.h"
#include "utils/messages.h"
#include "utils/url.h"
#include "utils/utf8.h"
#include "utils/utils.h"
#include "utils/log0.h"

#include "amiga/misc.h"

bool netsurf_quit = false;
extern struct plotter_table plot;
extern struct gui_utf8_table *amiga_utf8_table;
//struct gui_download_table *amiga_download_table = &download_table;

#define kprintf

APTR global_obj = NULL;

/* Forward declarations */
static struct browser_window *current_redraw_browser = NULL;
static bool browser_reformat_pending = false;
bool mui_redraw_pending = false;

char *default_stylesheet_url;
char *adblock_stylesheet_url;

#if defined(__MORPHOS__)
struct Library *ZBase;
struct Library *JFIFBase;
#endif

static struct MsgPort *schedulermsgport = NULL;
static struct MsgPort *appport;
static struct MsgPort *sport = NULL;
/* Object types */
enum {
	ASOT_PORT = 1,
	ASOT_IOREQUEST
};
/* Ignore unsupported tags */
#define ASO_NoTrack				TAG_IGNORE
static bool ami_gui_resources_open(void);

struct Library *TTEngineBase;
struct Library *IconBase;
struct IntuitionBase *IntuitionBase;
struct Library *SocketBase;
struct Library *AsyncIOBase;
struct Library *OpenURLBase;
struct Library *DiskfontBase;
struct Library *CyberGfxBase;
struct Library *MUIMasterBase;
//Added for AmigaOS 3.x
struct Library *AslBase, *LayersBase;
struct UtilityBase *UtilityBase = NULL;
struct GfxBase *GfxBase = NULL;
struct Library *IFFParseBase = NULL;
struct LocaleBase *LocaleBase = NULL;
struct Library *KeymapBase = NULL;
struct Device *TimerBase=NULL;
static struct IORequest timereq;
//nsamiga
struct Library *P96Base = NULL;
struct Library *GuiGFXBase = NULL;
struct Library *DataTypesBase = NULL;
//nsamiga
/////////
#if !defined(__MORPHOS2__)
struct Library *CodesetsBase;
#endif

#ifdef WITH_HUBBUB
static void *myrealloc(void *ptr, size_t len, void *pw)
{
	return realloc(ptr, len);
}
#endif

STATIC struct MinList download_list = { (APTR)&download_list.mlh_Tail, NULL, (APTR)&download_list };
STATIC struct MinList window_list = { (APTR)&window_list.mlh_Tail, NULL, (APTR)&window_list };
STATIC LONG process_priority;


/*********************************************************************/
struct Screen *ami_gui_get_screen(void)
{
	return LockPubScreen(NULL);
}

static void abort_downloads(void)
{
	struct gui_download_window *dw, *next;

	ITERATELISTSAFE(dw, next, &download_list)
	{
		CloseAsync(dw->fh);
		FreeMem(dw->dl, sizeof(struct download));
		FreeMem(dw, sizeof(*dw));
	}
}

void gui_window_destroy(struct gui_window *g);

static void gui_delete_windowlist(void)
{
	struct gui_window *g, *next;

	ITERATELISTSAFE(g, next, &window_list)
	{
		gui_window_destroy(g);
	}
}

static void cleanup(void)
{
	netsurf_exit();
	mui_schedule_finalise();
	methodstack_cleanup();

	gui_delete_windowlist();
	//bitmap_cleanup();
	transferanimclass_unload();

#if 0
	if (option_url_file && option_url_file[0])
		urldb_save(option_url_file);

	urldb_save_cookies(APPLICATION_COOKIES_FILE);
#endif

	mui_global_history_save();

	classes_cleanup();

	font_cleanup();

#ifdef WITH_HUBBUB
	//hubbub_finalise(myrealloc, NULL);
#endif

	mui_clipboard_free();

	/* When NetSurf is aborted we must cleanup everything manually */
	//mui_fetch_file_finalise(NULL);

	abort_downloads();

	#if !defined(__MORPHOS2__)
	CloseLibrary(CodesetsBase);
	#endif

	#if defined(__MORPHOS__)
	CloseLibrary(JFIFBase);
	CloseLibrary(ZBase);
	#endif

	if (OpenURLBase) CloseLibrary(OpenURLBase);
	CloseLibrary(AsyncIOBase);
	//CloseLibrary(SocketBase);
	CloseLibrary(TTEngineBase);
	CloseLibrary(DiskfontBase);
	CloseLibrary((struct Library *)IntuitionBase);
	CloseLibrary(IconBase);
	CloseLibrary(CyberGfxBase);
	CloseLibrary((struct Library *)GfxBase);
	CloseLibrary(MUIMasterBase);

	CloseLibrary((struct Library*)UtilityBase);
	CloseLibrary(IFFParseBase);
	CloseLibrary(LocaleBase);
	CloseLibrary(LayersBase);
	CloseLibrary(KeymapBase);
	//nsamiga
	CloseLibrary(GuiGFXBase);
	CloseLibrary(P96Base);
	CloseLibrary(DataTypesBase);
	//nsamiga
	#if defined(__MORPHOS__)
	NewSetTaskAttrsA(NULL, &process_priority, sizeof(ULONG), TASKINFOTYPE_PRI, NULL);
	#else
	SetTaskPri(SysBase->ThisTask, process_priority);
	#endif
}

static LONG startup(void)
{
    #if defined(__MORPHOS2__)
    #define TTENGINE_VERSION 8
    #else
    #define TTENGINE_VERSION 7
    #endif

    LOG(("DEBUG: Starting library initialization\n"));

    // Open muimaster.library
    MUIMasterBase = OpenLibrary("muimaster.library", 20);
    LOG(("DEBUG: muimaster.library %s\n", MUIMasterBase ? "opened" : "FAILED to open"));
    if (!MUIMasterBase) goto cleanup;

    // Open cybergraphics.library
    CyberGfxBase = OpenLibrary("cybergraphics.library", 39);
    LOG(("DEBUG: cybergraphics.library %s\n", CyberGfxBase ? "opened" : "FAILED to open"));
    if (!CyberGfxBase) goto cleanup;

	// Open GFXBase
	GfxBase = (struct GfxBase *)OpenLibrary("graphics.library", 39);
	LOG(("DEBUG: graphics.library %s\n", GfxBase ? "opened" : "FAILED to open"));
	if (!GfxBase) goto cleanup;
//nsamiga
	// Open picasso96api.library (if available)
	P96Base = (struct P96Base *) OpenLibrary("Picasso96API.library", 0);
	LOG(("DEBUG: Picasso96API.library %s\n", P96Base ? "opened" : "not available"));
	if (!P96Base) goto cleanup;

	GuiGFXBase = OpenLibrary("guigfx.library", 0);
	LOG(("DEBUG: guigfx.library %s\n", GuiGFXBase ? "opened" : "not available"));
	if (!GuiGFXBase) goto cleanup;

	DataTypesBase = OpenLibrary("datatypes.library", 39);
	LOG(("DEBUG: datatypes.library %s\n", DataTypesBase ? "opened" : "not available"));
	if (!DataTypesBase) goto cleanup;
//nsamiga
	#if !defined(__MORPHOS2__)
	// Open CodesetsBase
	CodesetsBase = OpenLibrary("codesets.library", 0);
	LOG(("DEBUG: codesets.library %s\n", CodesetsBase ? "opened" : "FAILED to open"));
	if (!CodesetsBase) goto cleanup;
	#endif

	// Open OpenURLBase
	OpenURLBase = OpenLibrary("openurl.library", 0);
	LOG(("DEBUG: openurl.library %s\n", OpenURLBase ? "opened" : "FAILED to open"));
	if (!OpenURLBase) goto cleanup;

	#if defined(__MORPHOS__)
	// Save current process priority and set higher priority for this task
	process_priority = FindTask(NULL)->tc_Node.ln_Pri;
	NewSetTaskAttrsA(NULL, &(LONG){process_priority + 5}, sizeof(ULONG), TASKINFOTYPE_PRI, NULL);
	#else
	// Save current task priority and set higher priority for this task
	process_priority = SetTaskPri(SysBase->ThisTask, 20);
	#endif

    
	#ifdef __MORPHOS__
    // Open z.library
    ZBase = OpenLibrary("z.library", 51);
    LOG(("DEBUG: z.library %s\n", ZBase ? "opened" : "FAILED to open"));
    if (!ZBase) goto cleanup;

    // Open jfif.library
    JFIFBase = OpenLibrary("jfif.library", 0);
    LOG(("DEBUG: jfif.library %s\n", JFIFBase ? "opened" : "FAILED to open"));
    if (!JFIFBase) goto cleanup;
    #endif
    //Open DiskfontBase
    DiskfontBase = OpenLibrary("diskfont.library", 39);
    if (!DiskfontBase) {
            LOG(("DEBUG: diskfont.library not available\n"));
            DiskfontBase = NULL; // Set to NULL if not available
        } else {
            LOG(("DEBUG: diskfont.library opened successfully\n"));
        } 	
	LOG(("DEBUG: Opening timer.device for TimerBase"));

	// Utwórz IORequest dla timer.device
	struct IORequest *timer_io = CreateIORequest(CreateMsgPort(), sizeof(struct timerequest));
	if (timer_io) {
		if (OpenDevice("timer.device", UNIT_VBLANK, timer_io, 0) == 0) {
			TimerBase = timer_io->io_Device;
			LOG(("DEBUG: TimerBase opened successfully: %p", TimerBase));
		} else {
			LOG(("ERROR: Failed to open timer.device for TimerBase"));
			DeleteIORequest(timer_io);
			goto cleanup;
		}
	} else {
		LOG(("ERROR: Failed to create IORequest for timer.device"));
		goto cleanup;
	}
    // Open asl.library
    AslBase = OpenLibrary("asl.library", 37);
    LOG(("DEBUG: asl.library %s\n", AslBase ? "opened" : "FAILED to open"));
    if (!AslBase) goto cleanup;

    // Open ttengine.library
    TTEngineBase = OpenLibrary("ttengine.library", TTENGINE_VERSION);
    LOG(("DEBUG: ttengine.library %s\n", TTEngineBase ? "opened" : "FAILED to open"));
    if (!TTEngineBase) goto cleanup;

    // Open icon.library
    IconBase = OpenLibrary("icon.library", 0);
    LOG(("DEBUG: icon.library %s\n", IconBase ? "opened" : "FAILED to open"));
    if (!IconBase) goto cleanup;

    // Open intuition.library
    IntuitionBase = (struct IntuitionBase *)OpenLibrary("intuition.library", 36);
    LOG(("DEBUG: intuition.library %s\n", IntuitionBase ? "opened" : "FAILED to open"));
    if (!IntuitionBase) goto cleanup;

    // Open bsdsocket.library
	//if (!SocketBase)
    //SocketBase = OpenLibrary("bsdsocket.library", 0);
    //LOG(("DEBUG: bsdsocket.library %s\n", SocketBase ? "opened" : "FAILED to open"));
   // if (!SocketBase) goto cleanup;

    // Open asyncio.library
    AsyncIOBase = OpenLibrary("asyncio.library", 0);
    LOG(("DEBUG: asyncio.library %s\n", AsyncIOBase ? "opened" : "FAILED to open"));
    if (!AsyncIOBase) goto cleanup;

    // Open utility.library
    UtilityBase = (struct UtilityBase *)OpenLibrary("utility.library", 37);
    LOG(("DEBUG: utility.library %s\n", UtilityBase ? "opened" : "FAILED to open"));
    if (!UtilityBase) goto cleanup;

    // Open iffparse.library
    IFFParseBase = OpenLibrary("iffparse.library", 0);
    LOG(("DEBUG: iffparse.library %s\n", IFFParseBase ? "opened" : "FAILED to open"));
    if (!IFFParseBase) goto cleanup;

	LayersBase = OpenLibrary("layers.library", 0);
	LOG(("DEBUG: layers.library %s\n", LayersBase ? "opened" : "FAILED to open"));
	if (!LayersBase) {
		LOG(("DEBUG: layers.library not available\n"));
		goto cleanup;
	}
    // Open locale.library
    LocaleBase = OpenLibrary("locale.library", 37);
    LOG(("DEBUG: locale.library %s\n", LocaleBase ? "opened" : "FAILED to open"));
    if (!LocaleBase) {
        LOG(("DEBUG: locale.library not available\n"));
        goto cleanup;
    }
	KeymapBase = OpenLibrary("keymap.library", 0);
	LOG(("DEBUG: keymap.library %s\n", KeymapBase ? "opened" : "FAILED to open"));
	if (!KeymapBase) {
		LOG(("DEBUG: keymap.library not available\n"));
		goto cleanup;
	}
	    // Initialize classes
    LOG(("DEBUG: Initializing classes...\n"));
    if (!classes_init()) {
        LOG(("DEBUG: classes_init FAILED\n"));
        goto cleanup;
    }
    LOG(("DEBUG: classes_init succeeded\n"));

    // Initialize mui_schedule
    LOG(("DEBUG: Initializing mui_schedule...\n"));
    if (!mui_schedule_init()) {
        LOG(("DEBUG: mui_schedule_init FAILED\n"));
        goto cleanup;
    }
    LOG(("DEBUG: mui_schedule_init succeeded\n"));

    // Initialize mui_clipboard
    LOG(("DEBUG: Initializing mui_clipboard...\n"));
    if (!mui_clipboard_init()) {
        LOG(("DEBUG: mui_clipboard_init FAILED\n"));
        goto cleanup;
    }
    LOG(("DEBUG: mui_clipboard_init succeeded\n"));

    // Initialize methodstack
    LOG(("DEBUG: Initializing methodstack...\n"));
    methodstack_init();
    LOG(("DEBUG: methodstack_init succeeded\n"));


    // Load transferanimclass
    LOG(("DEBUG: Loading transferanimclass...\n"));
    transferanimclass_load(); //arczi
    LOG(("DEBUG: transferanimclass loaded\n"));

    LOG(("DEBUG: Startup completed successfully\n"));
    return TRUE;

cleanup:
    LOG(("DEBUG: Cleaning up due to initialization failure\n"));
	if (KeymapBase) CloseLibrary(KeymapBase);
    if (LocaleBase) CloseLibrary((struct Library *)LocaleBase);
    if (IFFParseBase) CloseLibrary(IFFParseBase);
    if (UtilityBase) CloseLibrary((struct Library *)UtilityBase);
    if (AsyncIOBase) CloseLibrary(AsyncIOBase);
    if (SocketBase) CloseLibrary(SocketBase);
    if (IntuitionBase) CloseLibrary((struct Library *)IntuitionBase);
    if (IconBase) CloseLibrary(IconBase);
    if (TTEngineBase) CloseLibrary(TTEngineBase);
	if (DiskfontBase) CloseLibrary(DiskfontBase);
    if (AslBase) CloseLibrary(AslBase);
    #ifdef __MORPHOS__
    if (JFIFBase) CloseLibrary(JFIFBase);
    if (ZBase) CloseLibrary(ZBase);
    #endif
    if (AsyncIOBase) CloseLibrary(AsyncIOBase);
    //if (SocketBase) CloseLibrary(SocketBase);
    if (MUIMasterBase) CloseLibrary(MUIMasterBase);
    if (CyberGfxBase) CloseLibrary(CyberGfxBase);
	if (GfxBase) CloseLibrary((struct Library *)GfxBase);
	if (LayersBase) CloseLibrary(LayersBase);
    return FALSE;
}

/**
 * Set option defaults for mui frontend
 *
 * @param defaults The option table to update.
 * @return error status.
 */
static nserror set_defaults(struct nsoption_s *defaults)
{

	/* Set defaults for absent option strings */
	nsoption_setnull_charp(cookie_file, strdup("PROGDIR:Resources/Cookies"));
	nsoption_setnull_charp(cookie_jar, strdup("PROGDIR:Resources/Cookies"));
	//nsoption_setnull_charp(url_file, strdup("PROGDIR:Resources/URLs"));
	nsoption_setnull_charp(ca_bundle, strdup("PROGDIR:Resources/ca-bundle"));
	nsoption_setnull_charp(ca_path, strdup("PROGDIR:Resources/ca-path"));
	nsoption_setnull_charp(homepage_url, strdup("file:///PROGDIR:Resources/Welcome.html"));
	//nsoption_setnull_charp(default_stylesheet_url, strdup("file:///Resources/default.css"));
	//nsoption_setnull_charp(adblock_stylesheet_url, strdup("file:///Resources/adblock.css"));

	//nsoption_setnull_charp(net_player, strdup("C:ffplay"));
	//nsoption_setnull_charp(mpeg_player, strdup("C:Riva"));
	//nsoption_setnull_charp(download_path, strdup("Downloads/"));
	//nsoption_setnull_charp(cache_dir, strdup("PROGDIR:Resources/Cache"));
	//nsoption_setnull_charp(homepage_url, strdup("www.netsurf-browser.org/welcome"));
	//nsoption_setnull_charp(theme, strdup("PROGDIR:Resources/themes/default"));
	//nsoption_setnull_charp(download_manager, strdup("c/wallget"));
	//nsoption_setnull_charp(favicon_source, strdup("http://www.google.com/s2/favicons?domain="));


	if (nsoption_charp(cookie_file) == NULL ||
	    nsoption_charp(cookie_jar) == NULL) {
		NSLOG(netsurf, INFO,"Failed initialising cookie options");
		return NSERROR_BAD_PARAMETER;
	}

	return NSERROR_OK;
}

void gui_launch_url(const char *url);

void gui_quit(void)
{
		urldb_save_cookies(nsoption_charp(cookie_jar));
		LOG(("Attempting to close log file"));
		close_log_file();
}

static struct gui_misc_table mui_misc_table = {
	.schedule = mui_schedule,
	.launch_url = gui_launch_url,

	.quit = gui_quit,
};

//main

void gui_init2(int argc, char** argv)
{
	LOG(("DEBUG: gui_init2 called"));
	LOG(("DEBUG: argc=%d, argv=%p", argc, argv));
	LONG priority, got_window;
	struct nsurl *url;
	nserror error;

	priority = -1;
	got_window = 0;

	//mui_fetch_file_register();
	LOG(("DEBUG: gui_init2: mui_fetch_file_register called"));
#ifdef MULTITHREADED
	NewSetTaskAttrsA(NULL, &priority, sizeof(ULONG), TASKINFOTYPE_PRI, NULL);
#endif

	if (argc) {
		LOG(("DEBUG: gui_init2: argc > 0, processing command line arguments"));
		enum
		{
			ARG_URL = 0,
			ARG_COUNT
		};

		STATIC CONST TEXT template[] = "URL/A";
		struct RDArgs *args;
		IPTR array[ARG_COUNT] = {0}; //arczi było {NULL}

		if (args = ReadArgs(template, array, NULL)) {
			if (array[ARG_URL]) {
				STRPTR url_str;

				url_str = (char *)DupStr((char *)array[ARG_URL]);
				LOG(("DEBUG: gui_init2: URL from command line: %s", url_str));
				if (url_str) {
					error = nsurl_create(url_str, &url);
					LOG(("DEBUG: gui_init2: nsurl_create returned %d", error));
					if (error == NSERROR_OK) {
						struct browser_window *bw;
						LOG(("DEBUG: gui_init2: URL created successfully"));
						error = browser_window_create(BW_CREATE_HISTORY, url, NULL, NULL, &bw);
						if (error == NSERROR_OK)
							got_window = 1;
						nsurl_unref(url);
					}
					free(url_str);
				}
			}

			FreeArgs(args);
		}
	} else {
		LOG(("DEBUG: gui_init2: argc == 0, checking Workbench startup message"));
		extern struct WBStartup *_WBenchMsg;
		struct WBStartup *WBenchMsg;
		struct WBArg *wbarg;
		ULONG i;

		WBenchMsg = (struct WBStartup *)argv;

		for (i = 1, wbarg = WBenchMsg->sm_ArgList + 1; i < WBenchMsg->sm_NumArgs; i++, wbarg++) {
			if (wbarg->wa_Lock && *wbarg->wa_Name) {
				STRPTR path = GetNameFromLock(wbarg->wa_Lock);
				LOG(("DEBUG: gui_init2: Path from lock: %s", path));
				if (path) {
					ULONG length;
					STRPTR file;

					length = strlen(path) + strlen(wbarg->wa_Name) + 4;
					file = AllocTaskPooled(length);
					LOG(("DEBUG: gui_init2: Allocated file %s buffer of length %lu",file, length));
					if (file) {
						strcpy(file, path);
						AddPart(file, wbarg->wa_Name, length);

						//error = nsurl_create_from_text(file, &url);
						error = nsurl_create(file, &url);
						LOG(("DEBUG: gui_init2: Converted path to URL"));
						if (error == NSERROR_OK) {
							struct browser_window *bw;
							error = browser_window_create(BW_CREATE_HISTORY, url, NULL, NULL, &bw);
							if (error == NSERROR_OK)
								got_window = 1;
							nsurl_unref(url);
						}

						FreeTaskPooled(file, length);
					}

					FreeVecTaskPooled(path);
				}
			}
		}
	}

    if (!got_window) {
        LOG(("DEBUG: No window from command line, creating default page"));
        methodstack_push_imm(application, 2, MM_Window_MenuAction, MNA_NEW_PAGE);
    }
	LOG(("DEBUG: function gui_init2 completed"));
}

void gui_multitask(void)
{
	if (netsurf_check_events(TRUE, schedule_sig) & schedule_sig)
		mui_schedule_poll();
}

void gui_poll1(bool active)
{
	if (active || browser_reformat_pending) {
		gui_multitask();
	}
	else
	{
		if (netsurf_check_events(FALSE, schedule_sig) & schedule_sig)
			mui_schedule_poll();
	}
}
void gui_poll(void)
{
	if (browser_reformat_pending ) {
		if (netsurf_check_events(TRUE, schedule_sig) & schedule_sig)
			mui_schedule_poll();
	} else {
		if (netsurf_check_events(FALSE, schedule_sig) & schedule_sig)
			mui_schedule_poll();
	}
}

void gui_poll3(/*bool active*/)
{
//    LOG(("DEBUG: gui_poll ENTRY, active=%s", active ? "true" : "false"));
    
    // ZAWSZE sprawdź scheduler - to jest kluczowe!
    //LOG(("DEBUG: Checking scheduler signals"));
    
    // Sprawdź czy są sygnały do obsłużenia
    ULONG signals = SetSignal(0, 0); // Pobierz aktualne sygnały
   // LOG(("DEBUG: Current signals: 0x%08lx, schedule_sig: 0x%08lx", signals, schedule_sig));
    
    if (signals & schedule_sig) {
      //  LOG(("DEBUG: Schedule signal detected - calling mui_schedule_poll"));
       // mui_schedule_poll();
     //   LOG(("DEBUG: mui_schedule_poll completed"));
    }
    
    // Reszta obsługi GUI...
    if (/*active ||*/ browser_reformat_pending) {
        gui_multitask();
    }
    
   // LOG(("DEBUG: gui_poll EXIT"));
}
struct gui_window *gui_create_browser_window(struct browser_window *bw,
        struct browser_window *clone, bool new_tab)
{
    LOG(("DEBUG: gui_create_browser_window ENTRY"));
    LOG(("DEBUG: bw=%p, clone=%p, new_tab=%s", bw, clone, new_tab ? "true" : "false"));
    
    struct gui_window *gw;

    LOG(("DEBUG: Allocating gui_window structure"));
    gw = AllocMem(sizeof(*gw), MEMF_ANY);

    if (gw) {
        LOG(("DEBUG: gui_create_browser_window: gw allocated = %p", gw));
        gw->bw = bw;
        gw->pointertype = -1;
        LOG(("DEBUG: gui_create_browser_window - bw = %p", bw));
        LOG(("DEBUG: gui_create_browser_window - gw->bw = %p", gw->bw));
        LOG(("DEBUG: About to call methodstack_push_sync for MM_Application_AddBrowser"));
        LOG(("DEBUG: application object = %p", application));
        
        gw->obj = (APTR)methodstack_push_sync(application, 2,
                MM_Application_AddBrowser, gw);

        LOG(("DEBUG: methodstack_push_sync returned obj = %p", gw->obj));

        if (gw->obj == NULL) {
            LOG(("ERROR: methodstack_push_sync failed - freeing gw"));
            FreeMem(gw, sizeof(*gw));
            gw = NULL;
        } else {
            gw->BitMap = NULL;
            gw->Layer = NULL;
            gw->LayerInfo = NULL;
            //gw->RastPort = NULL;
            
            LOG(("DEBUG: gui_window created successfully"));
            LOG(("DEBUG: gw=%p, gw->obj=%p", gw, gw->obj));
            
            ADDTAIL(&window_list, gw);
            LOG(("DEBUG: Added to window_list"));
        }
    } else {
        LOG(("ERROR: Failed to allocate gui_window structure"));
    }

    LOG(("DEBUG: gui_create_browser_window returning %p", gw));
    return gw;
}



void gui_window_destroy(struct gui_window *g)
{
	REMOVE(g);

	if (g->win && !netsurf_quit)
		methodstack_push_sync(g->win, 2, MM_Window_RemovePage, g->obj);

	if (g->Layer) {
		TT_DoneRastPort(g->RastPort);
		DeleteLayer(0, g->Layer);
	}

	if (g->LayerInfo)
		DisposeLayerInfo(g->LayerInfo);

	FreeBitMap(g->BitMap);
	FreeMem(g, sizeof(*g));
}

void gui_window_set_title(struct gui_window *g, const char *title)
{
	methodstack_push_sync(g->obj, 3, MUIM_Set, MA_Browser_Title, title);
}

static void gui_redraw_all(struct gui_window *g)
{

}

void gui_window_redraw(struct gui_window *g, int x0, int y0, int x1, int y1)
{
    struct hlcache_handle *c = browser_window_get_content(g->bw);
	
    LOG(("DEBUG: gui_window_redraw called for browser window %p", g->bw));
   
    if (!c) {
        LOG(("ERROR: No content available"));
        return;
    }

    if (!_win(g->obj)) {
        LOG(("WARNING: Window not ready, skipping redraw"));
        return;
    }

    struct RastPort *screen_rp = _rp(g->obj);
    if (!screen_rp) {
        LOG(("ERROR: No screen RastPort"));
        return;
    }

    LOG(("DEBUG: Using direct screen rendering"));

    // USUŃ stare globalne zmienne:
    // current_redraw_browser = g->bw;  ← USUŃ
    // plot = muiplot;                  ← USUŃ

    // Przygotuj kontekst rysowania z plotters
    struct redraw_context ctx = {
        .interactive = true,
        .background_images = true,
        .plot = &amiplot//muiplot  // ← BEZPOŚREDNIO muiplot, nie przez globalną zmienną
    };
    
    // WAŻNE: Ustaw RastPort w plotters PRZED wywołaniem
    renderinfo.rp = screen_rp;
    renderinfo.width = _mwidth(g->obj);
    renderinfo.height = _mheight(g->obj);
	renderinfo.origin_x = _mleft(g->obj);
	renderinfo.origin_y = _mtop(g->obj);

    struct rect clip = {
        .x0 = x0,
        .y0 = y0,
        .x1 = x1,
        .y1 = y1
    };

    // UŻYJ browser_window_redraw zamiast content_redraw!
    LOG(("DEBUG: Calling browser_window_redraw"));
    bool redraw_success = browser_window_redraw(g->bw,
                                                _mleft(g->obj) - x0,
                                                _mtop(g->obj) - y0,
                                                &clip,
                                                &ctx);

    if (redraw_success) {
        LOG(("DEBUG: browser_window_redraw completed successfully"));
    } else {
        LOG(("ERROR: browser_window_redraw failed"));
    }
}

void gui_window_redraw_cr(struct gui_window *g, int x0, int y0, int x1, int y1)
{
    struct hlcache_handle *c;
    
    c = browser_window_get_content(g->bw);
    LOG(("DEBUG: gui_window_redraw called for browser window %p", g->bw));
   
    if (c)
    {
        LOG(("DEBUG: Content available, checking if window is ready"));
       
        // Jeśli okno nie jest gotowe, po prostu pomiń renderowanie
        if (!_win(g->obj)) {
            LOG(("WARNING: Window not ready, skipping redraw"));
            return;
        }
       
        struct RastPort *screen_rp = _rp(g->obj);
        LOG(("DEBUG: Screen RastPort: %p", screen_rp));
       
        if (screen_rp) {
            LOG(("DEBUG: Using direct screen rendering"));
           
            renderinfo.rp = screen_rp;
           
            g->redraw = 0;
            current_redraw_browser = g->bw;
//            plot = muiplot;
            
            int content_width, content_height;
            if (browser_window_get_extents(g->bw, false, &content_width, &content_height) == NSERROR_OK) {
                renderinfo.width = content_width;
                renderinfo.height = content_height;
            } else {
                renderinfo.width = 800;  // fallback
                renderinfo.height = 600;
            }
            
            LOG(("DEBUG: About to call content_redraw"));
            
            // Sprawdź czy x0, y0, x1, y1 są w granicach okna
            if (x0 < 0) x0 = 0;
            if (y0 < 0) y0 = 0;
            if (x1 > renderinfo.width) x1 = renderinfo.width;
            if (y1 > renderinfo.height) y1 = renderinfo.height;
            if (x1 < x0) x1 = x0; // Zapewnij, że x1 >= x0
            if (y1 < y0) y1 = y0; // Zapewnij, że y1 >= y0
            
            LOG(("DEBUG: Calling content_redraw with x0=%d, y0=%d, x1=%d, y1=%d", x0, y0, x1, y1));
           
            // Przygotuj kontekst rysowania
            struct redraw_context ctx = {
                .interactive = true,
                .background_images = true,
                .plot = &amiplot //muiplot
            };
           
            // Przygotuj prostokąt przycinania
            struct rect clip = {
                .x0 = x0,
                .y0 = y0,
                .x1 = x1,
                .y1 = y1
            };
           
            // Przygotuj dane rysowania dla nowego API
            struct content_redraw_data redraw_data = {
                .x = _mleft(g->obj) - x0,
                .y = _mtop(g->obj) - y0,
                .width = _mwidth(g->obj),
                .height = _mheight(g->obj),
                .background_colour = 0xFFFFFF,  // białe tło
                .scale = 1.0f,
                .repeat_x = false,
                .repeat_y = false
            };
            
            LOG(("DEBUG: Redraw data: x=%d, y=%d, width=%d, height=%d", 
                 redraw_data.x, redraw_data.y, redraw_data.width, redraw_data.height));
            
            // Wywołaj content_redraw z nowym API
            bool redraw_success = content_redraw(c, &redraw_data, &clip, &ctx);
            
            if (redraw_success) {
                LOG(("DEBUG: content_redraw completed successfully"));
            } else {
                LOG(("ERROR: content_redraw failed"));
            }
            
            current_redraw_browser = NULL;
            LOG(("DEBUG: Direct screen rendering completed"));
        } else {
            LOG(("ERROR: No screen RastPort even though window exists"));
        }
       
        LOG(("DEBUG: gui_window_redraw completed successfully"));
    }
    else
    {
        LOG(("ERROR: No content available"));
        
        // Opcjonalnie: narysuj placeholder gdy nie ma contentu
        if (_win(g->obj) && _rp(g->obj)) {
            struct RastPort *rp = _rp(g->obj);
            
            // Wypełnij białym tłem
            SetAPen(rp, 0);  // białe tło
            RectFill(rp, x0, y0, x1-1, y1-1);
            
            // Narysuj tekst "No Content"
            SetAPen(rp, 1);  // czarny tekst
            Move(rp, x0 + 10, y0 + 20);
            Text(rp, "No Content", 10);
            
            LOG(("DEBUG: Drew no-content placeholder"));
        }
    }
}
#if 0

#endif
void gui_window_redraw_window(struct gui_window *g)
{
	LOG(("DEBUG: gui_window_redraw_window called for browser window"));
#if 0
	struct hlcache_handle *c;
	int width, height;

	c = browser_window_get_content(g->bw);

	if (c && browser_window_get_extents(g->bw, false, &width, &height) == NSERROR_OK)
		gui_window_redraw(g, 0, 0, width, height);
#else
LOG(("DEBUG: gui_window_redraw_window called for browser window %p", g->bw));
	methodstack_push_sync(g->obj, 1, MM_Browser_Redraw);
#endif
}

void gui_window_update_box(struct gui_window *g, const union content_msg_data *data)
{
    struct hlcache_handle *c;
    LOG(("DEBUG: gui_window_update_box called for browser window"));
    c = browser_window_get_content(g->bw);
    if (c)
    {
		LOG(("DEBUG: Content available, checking if window is ready"));
        renderinfo.rp = (APTR)methodstack_push_sync(g->obj, 3, MM_Browser_GetBitMap,
                                                    content_get_width(c), content_get_height(c));
        if (g->RastPort)
        {
            if (g->redraw)
            {
                int width, height;
                if (browser_window_get_extents(g->bw, false, &width, &height) == NSERROR_OK)
                    gui_window_redraw(g, 0, 0, width, height);
            }
            else
            {
                //current_redraw_browser = g->bw;
                //plot = muiplot;
                renderinfo.rp = g->RastPort;
                renderinfo.width = content_get_width(c);
                renderinfo.height = content_get_height(c);
                
                // Przygotuj kontekst rysowania
                struct redraw_context ctx = {
                    .interactive = true,
                    .background_images = true,
                    .plot = &amiplot//muiplot
                };
               
                // Przygotuj prostokąt przycinania
                struct rect clip = {
                    .x0 = data->redraw.x,
                    .y0 = data->redraw.y,
                    .x1 = data->redraw.x + data->redraw.width,
                    .y1 = data->redraw.y + data->redraw.height
                };
                
                // Przygotuj dane rysowania dla nowego API
                struct content_redraw_data redraw_data = {
                    .x = 0,
                    .y = 0,
                    .width = data->redraw.width + data->redraw.x,
                    .height = data->redraw.height + data->redraw.y,
                    .background_colour = 0xFFFFFF,  // białe tło
                    .scale = 1.0f,
                    .repeat_x = false,
                    .repeat_y = false
                };
                
                LOG(("DEBUG: gui_window_update_box - redrawing area (%d,%d) size %dx%d",
                     data->redraw.x, data->redraw.y, data->redraw.width, data->redraw.height));
                
                // Wywołaj content_redraw z nowym API
                bool redraw_success = content_redraw(c, &redraw_data, &clip, &ctx);
                
                if (redraw_success) {
                    LOG(("DEBUG: gui_window_update_box - content_redraw completed successfully"));
                } else {
                    LOG(("ERROR: gui_window_update_box - content_redraw failed"));
                }
                
                //current_redraw_browser = NULL;
                methodstack_push_imm(g->obj, 1, MM_Browser_Redraw);
            }
        }
    }
}

bool gui_window_get_scroll(struct gui_window *g, int *sx, int *sy)
{
	methodstack_push(g->obj, 3, OM_GET, MUIA_Virtgroup_Left, sx);
	methodstack_push_imm(g->obj, 3, OM_GET, MUIA_Virtgroup_Top, sy);
	return true;
}

void gui_window_set_scroll(struct gui_window *g, int sx, int sy)
{
	IPTR tags[5];

	if (sx < 0)
		sx = 0;

	if (sy < 0)
		sy = 0;

	tags[0] = MUIA_Virtgroup_Left;
	tags[1] = sx;
	tags[2] = MUIA_Virtgroup_Top;
	tags[3] = sy;
	tags[4] = TAG_DONE;

	methodstack_push_sync(g->obj, 2, OM_SET, tags);
}

void gui_window_scroll_visible(struct gui_window *g, int x0, int y0, int x1, int y1)
{
	gui_window_set_scroll(g, x0, y0);
}

void gui_window_position_frame(struct gui_window *g, int x0, int y0, int x1, int y1)
{
}

/**
 * Find the current dimensions of a amiga browser window content area.
 *
 * \param gw The gui window to measure content area of.
 * \param width receives width of window
 * \param height receives height of window
 * \return NSERROR_OK on sucess and width and height updated
 *          else error code.
 */
static nserror gui_window_get_dimensions(struct gui_window *g, int *width, int *height, bool scaled)
{
	struct IBox bbox;
	int w, h;

	methodstack_push_sync(g->obj, 3, OM_GET, MA_Browser_Box, &bbox);
	
	LOG(("gui_window_get_dimensions() called, bbox: Left=%d, Top=%d, Width=%d, Height=%d",
		bbox.Left, bbox.Top, bbox.Width, bbox.Height));

	w = bbox.Width;
	h = bbox.Height;

#if 0
	if (scaled)
	{
		w /= g->bw->scale;
		h /= g->bw->scale;
	}
#else
	//#warning gui_window_get_dimensions(): scaled boolean not supported
#endif

	*width = w;
	*height = h;

	return NSERROR_OK;
}

void gui_window_update_extent(struct gui_window *g)
{
	LOG(("gui_window_update_extent() called"));

	if (g == NULL || g->bw == NULL) {
		LOG(("Warning: gui_window_update_extent called with NULL gui_window or browser_window"));
		return;
	}

	int width ;
	int height ;
//not sure which one to use
	browser_window_get_extents(g->bw, true, &width, &height);

	methodstack_push(g->obj, 3, MM_Browser_SetContentSize, width, height);

	LOG(("Updating content size to %d x %d", width, height));
}


void gui_window_set_status(struct gui_window *g, const char *text)
{
	global_obj = g->obj;
	//LOG(("DEBUG: gui_window_set_status: %s\n", text));
	methodstack_push_sync(g->obj, 3, MUIM_Set, MA_Browser_StatusText, text);
}

void gui_window_set_pointer(struct gui_window *g, gui_pointer_shape shape)
{

	ULONG pointertype = POINTERTYPE_NORMAL;

	switch (shape) {
	case GUI_POINTER_DEFAULT:
		pointertype = POINTERTYPE_NORMAL;
		break;

	case GUI_POINTER_POINT:
		pointertype = POINTERTYPE_LINK;//SELECTLINK;
		break;
    #if defined(__MORPHOS__)
	case GUI_POINTER_CARET:
	case GUI_POINTER_MENU:
	case GUI_POINTER_UP:
	case GUI_POINTER_DOWN:
	case GUI_POINTER_LEFT:
	case GUI_POINTER_RIGHT:
	case GUI_POINTER_RU:
	case GUI_POINTER_LD:
	case GUI_POINTER_LU:
	case GUI_POINTER_RD:
		break;

	case GUI_POINTER_CROSS:
		pointertype = POINTERTYPE_AIMING;
		break;

	case GUI_POINTER_MOVE:
		pointertype = POINTERTYPE_MOVE;
		break;

	case GUI_POINTER_WAIT:
		pointertype = POINTERTYPE_BUSY;
		break;

	case GUI_POINTER_HELP:
		pointertype = POINTERTYPE_HELP;
		break;

	case GUI_POINTER_NO_DROP:
	case GUI_POINTER_NOT_ALLOWED:
		pointertype = POINTERTYPE_NOTAVAILABLE;
		break;

	case GUI_POINTER_PROGRESS:
		pointertype = POINTERTYPE_WORKING;
		break;
    #endif    
	}

	if (g->pointertype != pointertype) {
		g->pointertype = pointertype;
		methodstack_push(g->obj, 3, MUIM_Set, MA_Browser_Pointer, pointertype);
	}
//	#endif
}

void gui_window_hide_pointer(struct gui_window *g)
{
	if (g->pointertype != POINTERTYPE_INVISIBLE) {
		g->pointertype = POINTERTYPE_INVISIBLE;
		methodstack_push(g->obj, 3, MUIM_Set, MA_Browser_Pointer, POINTERTYPE_INVISIBLE);
	}
}

static nserror
gui_window_set_url(struct gui_window *g, nsurl *url)
{
	LOG(("DEBUG: gui_window_set_url called with URL: %s", nsurl_access(url)));

	methodstack_push_sync(g->obj, 3, MUIM_Set, MA_Browser_URL, nsurl_access(url));
	return NSERROR_OK;
}

void gui_window_start_throbber(struct gui_window *g)
{
	methodstack_push_imm(g->obj, 3, MUIM_Set, MA_Browser_Loading, TRUE);
	//mui_redraw_pending = TRUE; // Ensure the throbber is redrawn
}

void gui_window_stop_throbber(struct gui_window *g)
{
	methodstack_push_imm(g->obj, 3, MUIM_Set, MA_Browser_Loading, FALSE);
	//mui_redraw_pending = false; // Ensure the throbber is redrawn
}

void gui_window_place_caret(struct gui_window *g, int x, int y, int height)
{

}


void gui_window_remove_caret(struct gui_window *g)
{

}

/**
 * Called when the gui_window has new content.
 *
 * \param  g  the gui_window that has new content
 */

static void gui_window_new_content22(struct gui_window *g)
{
	struct hlcache_handle *c = browser_window_get_content(g->bw);
	LOG(("DEBUG: gui_window_new_content called for browser window"));
	if (c) {
		LOG(("DEBUG: Content available, setting content type"));
		content_type type = content_get_type(c);
		methodstack_push(g->obj, 2, MM_Browser_SetContentType, type);
	}
	else
		LOG(("DEBUG: gui_window_new_content called but no content available for browser window %p", g->bw));
}
static void gui_window_new_content(struct gui_window *g)
{
    struct hlcache_handle *c = browser_window_get_content(g->bw);
    LOG(("DEBUG: gui_window_new_content called for browser window"));
    
    if (c) {
        LOG(("DEBUG: Content available, setting content type"));
        content_type type = content_get_type(c);
        methodstack_push(g->obj, 2, MM_Browser_SetContentType, type);
        
        // ⭐ NOWE: Wywołaj content ready trigger
        LOG(("DEBUG: Content ready - triggering redraw"));
    //    / mui_trigger_content_ready_redraw(g->obj);
    }
    else {
        LOG(("DEBUG: gui_window_new_content called but no content available for browser window %p", g->bw));
    }
}
bool gui_window_scroll_start(struct gui_window *g)
{
	//return true;
}

bool gui_window_box_scroll_start(struct gui_window *g, int x0, int y0, int x1, int y1)
{
	//return true;
}

bool gui_window_frame_resize_start(struct gui_window *g)
{
	//return true;
}

void gui_window_save_as_link(struct gui_window *g, struct hlcache_handle *c)
{
}

void gui_window_set_scale(struct gui_window *g, float scale)
{
}

struct gui_download_window *gui_download_window_create(const char *url,
		const char *mime_type, struct fetch *fetch,
		unsigned int total_size, struct gui_window *gui)
{
	struct gui_download_window *dw;

	dw = AllocMem(sizeof(*dw), MEMF_ANY);

	if (dw)
	{
		struct download *dl;
		ULONG ok;

		dl = (APTR)methodstack_push_sync(application, 2, MM_Application_Download, url);
		ok = 0;

		if (dl)
		{
			BPTR lock;

			dw->dl = dl;
			dl->size = total_size;

			lock = Lock(dl->path, ACCESS_READ);

			if (lock)
			{
				lock = CurrentDir(lock);

				dw->fh = OpenAsync(dl->filename, MODE_WRITE, 8192);

				if (dw->fh)
				{
					ADDTAIL(&download_list, dw);
					SetComment(dl->filename, url);
					ok = 1;
				}

				UnLock(CurrentDir(lock));
			}
		}

		if (!ok)
		{
			if (dl)
			{
				methodstack_push_sync(application, 2, MM_Application_DownloadError, dw->dl);
			}
			else
			{
				FreeMem(dw, sizeof(*dw));
			}

			dw = NULL;
		}
	}

	return dw;
}

/**
 * process miscellaneous window events
 *
 * \param gw The window receiving the event.
 * \param event The event code.
 * \return NSERROR_OK when processed ok
 */
static nserror
gui_window_event1(struct gui_window *gw, enum gui_window_event event)
{
	switch (event) {
	case GW_EVENT_UPDATE_EXTENT:
		gui_window_update_extent(gw);
		break;

	case GW_EVENT_REMOVE_CARET:
		gui_window_remove_caret(gw);
		break;

	case GW_EVENT_NEW_CONTENT:
		gui_window_new_content(gw);
		break;

	case GW_EVENT_START_THROBBER:
		gui_window_start_throbber(gw);
		break;

	case GW_EVENT_STOP_THROBBER:
		gui_window_stop_throbber(gw);
		break;

	default:
		break;
	}
	return NSERROR_OK;
}
static nserror
gui_window_event(struct gui_window *gw, enum gui_window_event event)
{
    LOG(("DEBUG: gui_window_event called with event=%d", event));
    
    switch (event) {
    case GW_EVENT_UPDATE_EXTENT:
        LOG(("DEBUG: GW_EVENT_UPDATE_EXTENT"));
        gui_window_update_extent(gw);
        break;

    case GW_EVENT_REMOVE_CARET:
        LOG(("DEBUG: GW_EVENT_REMOVE_CARET"));
        //gui_window_remove_caret(gw);
        break;

    case GW_EVENT_NEW_CONTENT:
        LOG(("DEBUG: GW_EVENT_NEW_CONTENT - calling gui_window_new_content"));
        gui_window_new_content(gw);
		
		if (gw && gw->obj) {
            //mui_trigger_content_ready_redraw(gw->obj);
        }
        break;

    case GW_EVENT_START_THROBBER:
        LOG(("DEBUG: GW_EVENT_START_THROBBER"));
        gui_window_start_throbber(gw);
        break;

    case GW_EVENT_STOP_THROBBER:
        LOG(("DEBUG: GW_EVENT_STOP_THROBBER"));
        gui_window_stop_throbber(gw);
        break;

    case GW_EVENT_PAGE_INFO_CHANGE:
        LOG(("DEBUG: GW_EVENT_PAGE_INFO_CHANGE"));
        // Handle page info changes if needed
        break;

    case GW_EVENT_SCROLL_START:
        LOG(("DEBUG: GW_EVENT_SCROLL_START"));
        // Handle scroll start if needed  
        break;

    case GW_EVENT_START_SELECTION:
        LOG(("DEBUG: GW_EVENT_START_SELECTION"));
        // Handle selection start if needed
        break;

    default:
        LOG(("DEBUG: Unknown window event: %d", event));
        break;
    }
    return NSERROR_OK;
}
static struct gui_window *
gui_window_create1(struct browser_window *bw,
		struct gui_window *existing,
		gui_window_create_flags flags)
{
	LOG(("DEBUG: gui_window_create called - bw=%p, existing=%p, flags=%d", bw, existing, flags));
	
	// Wywołaj istniejącą funkcję gui_create_browser_window
	// ale z właściwymi parametrami
	struct gui_window *gw = gui_create_browser_window(bw, 
		(existing && (flags & GW_CREATE_CLONE)) ? existing->bw : NULL, 
		(flags & GW_CREATE_TAB) ? true : false);
	
	LOG(("DEBUG: gui_window_create returning gw=%p", gw));
	return gw;
}
static struct gui_window *
gui_window_create(struct browser_window *bw,
        struct gui_window *existing,
        gui_window_create_flags flags)
{
    LOG(("DEBUG: gui_window_create ENTRY"));
    LOG(("DEBUG: bw=%p, existing=%p, flags=%d", bw, existing, flags));
    
    if (!bw) {
        LOG(("ERROR: gui_window_create: bw is NULL"));
        return NULL;
    }
    
    LOG(("DEBUG: About to call gui_create_browser_window"));
    
    // Wywołaj istniejącą funkcję gui_create_browser_window
    // ale z właściwymi parametrami
    struct gui_window *gw = gui_create_browser_window(bw, 
        (existing && (flags & GW_CREATE_CLONE)) ? existing->bw : NULL, 
        (flags & GW_CREATE_TAB) ? true : false);
    
    LOG(("DEBUG: gui_create_browser_window returned gw=%p", gw));
    
    if (!gw) {
        LOG(("ERROR: gui_create_browser_window failed"));
        return NULL;
    }
    
    LOG(("DEBUG: gui_window_create SUCCESS - returning gw=%p", gw));
    return gw;
}
/**
 * Ensures output logging stream is correctly configured
 */
static bool nslog_stream_configure(FILE *fptr)
{
		/* set log stream to be non-buffering */
	setbuf(fptr, NULL);

	return true;
}

/**
 * Invalidate an area of a window
 *
 * \param gw The window to invalidate
 * \param rect The rectangle to invalidate (in window coordinates)
 * \return NSERROR_OK on success
 */
static nserror gui_window_invalidate(struct gui_window *gw, const struct rect *rect)
{
    LOG(("DEBUG: gui_window_invalidate called"));
    LOG(("DEBUG: gw=%p, rect=%p", gw, rect));
   
    if (!gw) {
        LOG(("ERROR: gui_window_invalidate: gw is NULL"));
        return NSERROR_BAD_PARAMETER;
    }
   
    if (rect != NULL) {
        LOG(("DEBUG: gui_window_invalidate: invalidating area x0=%d, y0=%d, x1=%d, y1=%d",
             rect->x0, rect->y0, rect->x1, rect->y1));
        
        // Invalidate konkretny obszar
        gui_window_redraw(gw, rect->x0, rect->y0, rect->x1, rect->y1);
		
    } else {
        LOG(("DEBUG: gui_window_invalidate: invalidating ENTIRE window"));
        
        // ✅ Invalidate całe okno - wywołaj pełny redraw!
        methodstack_push_sync(gw->obj, 1, MM_Browser_Redraw);
    }
   
    LOG(("DEBUG: gui_window_invalidate: completed successfully"));
    return NSERROR_OK;
}

static struct gui_window_table mui_window_table = {
	.create = gui_window_create,
	.destroy = gui_window_destroy,
	.invalidate = gui_window_invalidate,
	.get_scroll = gui_window_get_scroll,
	.set_scroll = gui_window_set_scroll,
	.get_dimensions = gui_window_get_dimensions,
	.event = gui_window_event,

	.set_title = gui_window_set_title,
	.set_url = gui_window_set_url,
	.set_status = gui_window_set_status,
	.set_pointer = gui_window_set_pointer,
	.place_caret = gui_window_place_caret,
};

/**
 * Poll components which require it.
 */
void netsurf_poll2(void)
{
    LOG(("DEBUG: netsurf_poll called"));
    
    // Sprawdź czy scheduler ma zdarzenia do obsłużenia
   // gui_poll(true);  // czy fetch_active
    
    LOG(("DEBUG: netsurf_poll completed"));
}
void netsurf_poll(void)
{
	static unsigned int last_clean = 0;
	unsigned int current_time = wallclock();

	/* avoid calling content_clean() more often than once every 5
	 * seconds.
	 */
	if (last_clean + 500 < current_time) {
		last_clean = current_time;
		//hlcache_clean();
	}
	gui_poll();//fetch_active);
	//llcache_poll();
	//fetcher_poll();
}
/**
 * Gui NetSurf main loop.
 */

int netsurf_main_loop(void)
{
    LOG(("DEBUG: netsurf_main_loop ENTRY"));
    
    int iteration = 0;
    while (!netsurf_quit) {
        iteration++;
        
        if (iteration % 100 == 0) {
            LOG(("DEBUG: Main loop iteration %d", iteration));
        }
        
        // WAŻNE: Sprawdź scheduler PRZED netsurf_poll
        ULONG signals = SetSignal(0, 0);
        if (signals & schedule_sig) {
            LOG(("DEBUG: Schedule signal in main loop"));
            mui_schedule_poll();
        }
        
        netsurf_poll();
        
        // Mała pauza żeby nie obciążać CPU
        Delay(3);  // 1/50 sekundy
    }
    
    LOG(("DEBUG: netsurf_main_loop ended"));
    return 0;
}
int netsurf_main_loop1(void)
{
    LOG(("DEBUG: netsurf_main_loop started"));
    
    while (!netsurf_quit) {
        LOG(("DEBUG: netsurf_main_loop iteration"));
        netsurf_poll();
        
        // Dodaj krótką pauzę żeby nie obciążać CPU
        //Delay(1);  // 1/50 sekundy na Amidze
    }
    
    LOG(("DEBUG: netsurf_main_loop ended, netsurf_quit=%d", netsurf_quit));
    return 0;
}
/* DOS */
#define AllocSysObjectTags(A,B,C,D) CreateMsgPort() /* Assume ASOT_PORT for now */

static bool ami_gui_resources_open(void)
{
#ifdef __amigaos4__
	urlStringClass = MakeStringClass();
#endif
	LOG(("DEBUG: ami_gui_resources_open ENTRY"));
    /*if(!(appport = AllocSysObjectTags(ASOT_PORT,
							ASO_NoTrack, FALSE,
							TAG_DONE))) return false;

    if(!(sport = AllocSysObjectTags(ASOT_PORT,
							ASO_NoTrack, FALSE,
							TAG_DONE))) return false;*/

    if(!(schedulermsgport = AllocSysObjectTags(ASOT_PORT,
							ASO_NoTrack, FALSE,
							TAG_DONE))) return false;
	LOG(("DEBUG: ami_gui_resources_open SUCCESS"));
	//return true;
	if(ami_schedule_create(schedulermsgport) != NSERROR_OK) {
		warn_user("Failed to initialise scheduler");
		return false;
	}

	ami_object_init();

	return true;
}
void main(int argc, char** argv) //gui_init
{
	struct browser_window *bw;
	char *options;
	nsurl *url;
	nserror ret;

	//font_init();
//	LOG(("DEBUG: FUNCTION=%s LINE=%d \n", __FUNCTION__, __LINE__));

	// Initialize the GUI system
	struct netsurf_table mui_table = {
		.misc = &mui_misc_table,
		.window = &mui_window_table,
		.clipboard = mui_clipboard_table,
		.bitmap = amiga_bitmap_table, //mui_bitmap_table,
		.layout = mui_layout_table,
		.fetch = amiga_fetch_table,
		.file = amiga_file_table,
		.utf8 = amiga_utf8_table,
		//.download = amiga_download_table,
		.llcache = filesystem_llcache_table,
		};
	ret = netsurf_register(&mui_table);

	if (ret != NSERROR_OK) {
		LOG(("NetSurf operation table failed registration"));
		die("NetSurf operation table failed registration");
	}
	/* initialise logging. Not fatal if it fails but not much we
	 * can do about it either.
	 */
	SetTaskPri(FindTask("LimpidClock"), 0);


	process_priority = SysBase->ThisTask->tc_Node.ln_Pri;

	//LOG(("DEBUG: FUNCTION=%s LINE=%d \n", __FUNCTION__, __LINE__));
	atexit(cleanup);
	//LOG(("DEBUG: FUNCTION=%s LINE=%d \n", __FUNCTION__, __LINE__));
	if (startup())
	{
		struct Locale *locale;
		TEXT lang[100];
		BPTR lock, file;
		ULONG i, found;

	/* user options setup */
	ret = nsoption_init(set_defaults, &nsoptions, &nsoptions_default);
	if (ret != NSERROR_OK) {
		die("Options failed to initialise");
	}
	nsoption_commandline(&argc, argv, nsoptions);
	options = strdup("PROGDIR:Resources/Options");
	nsoption_read(options, nsoptions);
	LOG(("DEBUG: Options read from file: %s", options));
//	verbose_log = option_verbose_log;
	verbose_log = true;
			
	font_init();

	nslog_init(NULL, &argc, argv);
	LOG(("DEBUG: mui_table registered successfully"));

		/* message init */
		unsigned char messages[200];
		if (ami_locate_resource(messages, "Messages") == false) {
			ami_misc_fatal_error("Cannot open Messages file");
			return RETURN_FAIL;
		}

		ret = messages_add_from_file(messages);
		if (ret != NSERROR_OK)
			fprintf(stderr, "Cannot open Messages file");

		ret = netsurf_init("PROGDIR:Resources/Cache");
		//nsoption_charp(cache_dir));
		/* Override, since we have no support for non-core SELECT menu */
		nsoption_set_bool(core_select_menu, true);
	
		netsurf_setup();	
	#ifndef __amigaos4__
		/* OS3 low memory handler */
		struct Interupt *memhandler = ami_memory_init();
	#endif

	if (ami_gui_resources_open() == false)  /* alloc msgports, objects and other miscelleny */
		LOG(("DEBUG: NSERROR_OK returned from netsurf_init"));
		//plot = muiplot;

		//urldb_load(homepage_url);
		
		urldb_load_cookies(nsoption_charp(cookie_file));
		//mui_global_history_initialise();
		
		/* create an initial browser window */
		//mui_cookies_initialise(); //disabled for now
		//save_complete_init();
		NSLOG(netsurf, INFO,"calling browser_window_create");

		/*ret = nsurl_create("about:blank", &url);
		if (ret == NSERROR_OK) {
			ret = browser_window_create(BW_CREATE_HISTORY,
							url,
							NULL,
							NULL,
							&bw);
			nsurl_unref(url);
		}
		if (ret != NSERROR_OK)
			printf("Errorcode:", messages_get_errorcode(ret));
	*/		
	} //startup() 

    	LOG(("DEBUG: About to call gui_init2"));

   	 gui_init2(argc, argv);
	 	
	LOG(("DEBUG: gui_init2 completed"));
	LOG(("DEBUG: Starting MUI main loop using netsurf_check_events"));

while (!netsurf_quit) {

    mui_schedule_poll();

    ULONG signals;

    bool has_tasks = mui_schedule_has_tasks();
    
    if (mui_redraw_pending || has_tasks) {
        signals = netsurf_check_events(TRUE, schedule_sig);
    } else {
        signals = netsurf_check_events(FALSE, schedule_sig);
    }
    	if(signals & schedule_sig) {
		ami_schedule_handle(schedulermsgport);
	}
    // MUI application handling
    if (application) {
		//LOG(("DEBUG: MUI Application handling"));
		//while (DoMethod(obj->App, MUIM_Application_NewInput, (IPTR)&sigs)
		//	!= MUIV_Application_ReturnID_Quit)
		{
		
		    if (signals)
		      	{
		        signals = Wait(signals | SIGBREAKF_CTRL_C);
		        if (signals & SIGBREAKF_CTRL_C) break;
		      	}
		}
    }
    
    // ⭐ Czekaj na schedule_sig lub timer
   // ULONG signals = Wait(schedule_sig | SIGBREAKF_CTRL_C);
    
    if (signals & SIGBREAKF_CTRL_C) {
        netsurf_quit = true;
    }
}
	/*while (!netsurf_quit) {
		// 1. NetSurf poll
		netsurf_poll();
		
		// 2. Sprawdź scheduler
		ULONG signals = SetSignal(0, 0);
		if (signals & schedule_sig) {
			mui_schedule_poll();
		}
		
		// 3. MUI handling
		if (application) {
			ULONG app_signals = 0;
			ULONG app_result = DoMethod(application, MUIM_Application_NewInput, (IPTR)&app_signals);
			
			if (app_result == MUIV_Application_ReturnID_Quit) {
				LOG(("DEBUG: MUI Application quit requested"));
				netsurf_quit = true;
				break;
			}
		}
		
		// 4. Krótka pauza
		Delay(1);
	}*/
#if 0
	while (!netsurf_quit) {
		//LOG(("DEBUG: Main loop iteration"));
		
		//ULONG signals = netsurf_check_events(FALSE, schedule_sig);
		
		//LOG(("DEBUG: netsurf_check_events returned signals: 0x%08lx", signals));
		
		// SPRAWDŹ CZY MUI ŻĄDA ZAKOŃCZENIA:
//		if (signals & SIGBREAKF_CTRL_C) {
		//	LOG(("DEBUG: CTRL+C detected - setting netsurf_quit"));
		//	netsurf_quit = true;
		//	break;
	//	}
		
		// Sprawdź czy scheduler ma zdarzenia
		//if (signals & schedule_sig) {
		//	LOG(("DEBUG: Schedule signal detected - calling mui_schedule_poll"));
			//mui_schedule_poll();
			
	//	}
		netsurf_main_loop(); //netsurf_poll();
		// SPRAWDŹ APLIKACJĘ MUI:
		if (application) {
			ULONG app_signals = 0;
			ULONG app_result = DoMethod(application, MUIM_Application_NewInput, (IPTR)&app_signals);
			
			if (app_result == MUIV_Application_ReturnID_Quit) {
				LOG(("DEBUG: MUI Application quit requested"));
				netsurf_quit = true;
				break;
			}
		}
		
		// Sprawdź czy netsurf_quit zostało ustawione gdzieś indziej
		if (netsurf_quit) {
			LOG(("DEBUG: netsurf_quit detected - breaking main loop"));
			break;
		}
	}
#endif	
	netsurf_exit();
	/* finalise options */
	nsoption_finalise(nsoptions, nsoptions_default);

	/* finalise logging */
	nslog_finalise();
	LOG(("DEBUG: Main loop ended"));
	return 0;
}
#if 0
void main1(int argc, char** argv) //gui_init
{
	struct browser_window *bw;
	char *options;
	nsurl *url;

	LOG(("DEBUG: FUNCTION=%s LINE=%d \n", __FUNCTION__, __LINE__));
	//font_init();
	LOG(("DEBUG: FUNCTION=%s LINE=%d \n", __FUNCTION__, __LINE__));

	// Initialize the GUI system
	struct netsurf_table mui_table = {
		.misc = &mui_misc_table,
		.window = &mui_window_table,
		.clipboard = mui_clipboard_table,
		.bitmap = mui_bitmap_table,
		.layout = mui_layout_table,
		.fetch = amiga_fetch_table,
		.file = amiga_file_table,
		.utf8 = amiga_utf8_table,
		//.download = amiga_download_table,
		.llcache = filesystem_llcache_table,
		};
	//OpenDevice("timer.device", 0, &timereq, 0);
	//TimerBase = timereq.io_Device;

	/* initialise logging. Not fatal if it fails but not much we
	 * can do about it either.
	 */
	//SetTaskPri(FindTask("LimpidClock"), 0);
	nslog_init(nslog_stream_configure, &argc, argv);

	process_priority = SysBase->ThisTask->tc_Node.ln_Pri;

	LOG(("DEBUG: FUNCTION=%s LINE=%d \n", __FUNCTION__, __LINE__));
	atexit(cleanup);
	LOG(("DEBUG: FUNCTION=%s LINE=%d \n", __FUNCTION__, __LINE__));
	if (startup())
	{
		struct Locale *locale;
		TEXT lang[100];
		BPTR lock, file;
		ULONG i, found;

	/* user options setup */
	nserror ret = nsoption_init(set_defaults, &nsoptions, &nsoptions_default);
	if (ret != NSERROR_OK) {
		die("Options failed to initialise");
	}
	nsoption_commandline(&argc, argv, nsoptions);
	options = strdup("PROGDIR:Resources/Options");
	nsoption_read(options, nsoptions);
	LOG(("DEBUG: Options read from file: %s", options));
//	verbose_log = option_verbose_log;
	verbose_log = true;
	font_init();
	ret = netsurf_register(&mui_table);

	if (ret != NSERROR_OK) {
		LOG(("NetSurf operation table failed registration"));
		die("NetSurf operation table failed registration");
	}

	LOG(("DEBUG: mui_table registered successfully"));

		/* message init */
		unsigned char messages[200];
		if (ami_locate_resource(messages, "Messages") == false) {
			ami_misc_fatal_error("Cannot open Messages file");
			return RETURN_FAIL;
		}

		ret = messages_add_from_file(messages);
		if (ret != NSERROR_OK)
			fprintf(stderr, "Cannot open Messages file");
#if 0
		locale = OpenLocale(NULL);
		found = FALSE;

		for (i = 0;i < 10; i++) {
			if (locale->loc_PrefLanguages[i] == NULL)
				continue;

			strcpy(lang, "PROGDIR:Resources/");
			strcat(lang, messages_get(locale->loc_PrefLanguages[i]));
			strcat(lang, "/messages");

			if (lock = Lock(lang, ACCESS_READ)) {
				UnLock(lock);
				found = TRUE;
				break;
			}
		}
#else	
	found = FALSE;
#endif		
	LOG(("DEBUG: FUNCTION=%s LINE=%d \n", __FUNCTION__, __LINE__));
		if (!found)
			strcpy(lang, "PROGDIR:Resources/en/messages");
	LOG(("DEBUG: FUNCTION=%s LINE=%d \n", __FUNCTION__, __LINE__));
		//CloseLocale(locale);
	LOG(("DEBUG: FUNCTION=%s LINE=%d \n", __FUNCTION__, __LINE__));
		//messages_load(lang); // check locale language and read appropriate file
	LOG(("DEBUG: FUNCTION=%s LINE=%d \n", __FUNCTION__, __LINE__));
		//default_stylesheet_url = "file:///Resources/default.css";
		//adblock_stylesheet_url ="file:///Resources/adblock.css";
	LOG(("DEBUG: FUNCTION=%s LINE=%d \n", __FUNCTION__, __LINE__));
		netsurf_init("PROGDIR:Resources/Cache");
		netsurf_setup();	
#ifdef WITH_HUBBUB
		//if (hubbub_initialise("Resources/Aliases", myrealloc, NULL) != HUBBUB_OK)
		//	die(messages_get("NoMemory"));
#endif
		//nscss_screen_dpi = 90;
		LOG(("DEBUG: NSERROR_OK returned from netsurf_init"));
		plot = muiplot;

//		urldb_load(option_url_file);
		//urldb_load_cookies(APPLICATION_COOKIES_FILE);
		
		urldb_load_cookies(nsoption_charp(cookie_file));
		//mui_global_history_initialise();
		//mui_cookies_initialise(); //disabled for now
		save_complete_init();
/*		NSLOG(netsurf, INFO,"calling browser_window_create");

		ret = nsurl_create(nsoption_charp(homepage_url), &url);
		if (ret == NSERROR_OK) {
			ret = browser_window_create(BW_CREATE_HISTORY,
							nsoption_charp(homepage_url),
							NULL,
							NULL,
							&bw);
			nsurl_unref(url);
		}*/
		//return;
	}
    LOG(("DEBUG: About to call gui_init2"));
    gui_init2(argc, argv);
	LOG(("DEBUG: gui_init2 completed"));

	// UŻYJ ORYGINALNEJ PĘTLI MUI:
	LOG(("DEBUG: Starting MUI main loop using netsurf_check_events"));
	LOG(("DEBUG: schedule_sig = 0x%08lx", schedule_sig));

	// W głównej pętli main():

	while (!netsurf_quit) {
		LOG(("DEBUG: Main loop iteration"));
		
		ULONG signals = netsurf_check_events(FALSE, schedule_sig);
		
		LOG(("DEBUG: netsurf_check_events returned signals: 0x%08lx", signals));
		
		// SPRAWDŹ CZY MUI ŻĄDA ZAKOŃCZENIA:
		if (signals & SIGBREAKF_CTRL_C) {
			LOG(("DEBUG: CTRL+C detected - setting netsurf_quit"));
			netsurf_quit = true;
			break;
		}
		
		// Sprawdź czy scheduler ma zdarzenia
		if (signals & schedule_sig) {
			LOG(("DEBUG: Schedule signal detected - calling mui_schedule_poll"));
			mui_schedule_poll();
		}
		
		// SPRAWDŹ APLIKACJĘ MUI:
		if (application) {
			ULONG app_signals = 0;
			ULONG app_result = DoMethod(application, MUIM_Application_NewInput, (IPTR)&app_signals);
			
			if (app_result == MUIV_Application_ReturnID_Quit) {
				LOG(("DEBUG: MUI Application quit requested"));
				netsurf_quit = true;
				break;
			}
		}
		
		// Sprawdź czy netsurf_quit zostało ustawione gdzieś indziej
		if (netsurf_quit) {
			LOG(("DEBUG: netsurf_quit detected - breaking main loop"));
			break;
		}
	}

	LOG(("DEBUG: Main loop ended, netsurf_quit=%s", netsurf_quit ? "true" : "false"));

	LOG(("DEBUG: Main loop ended"));
	return 0;
}
#endif
void gui_download_window_data(struct gui_download_window *dw, const char *data, unsigned int size)
{
	WriteAsync(dw->fh, (APTR)data, size);

	dw->dl->done += size;

	methodstack_push(application, 1, MM_Application_DownloadUpdate);
}

void gui_download_window_error(struct gui_download_window *dw, const char *error_msg)
{
	methodstack_push_sync(application, 2, MM_Application_DownloadError, dw->dl);
}

void gui_download_window_done(struct gui_download_window *dw)
{
	methodstack_push_sync(application, 2, MM_Application_DownloadDone, dw->dl);
}

//void gui_drag_save_object(gui_save_type type, struct hlcache_handle *c, struct gui_window *g)
//{
//}

void gui_create_form_select_menu(struct browser_window *bw, struct form_control *control)
{
}

void gui_launch_url(const char *url)
{
	#if defined(__MORPHOS__)
	if (!strncmp("mailto:", url, 7))
	{
		if (OpenURLBase == NULL)
			OpenURLBase = OpenLibrary("openurl.library", 6);

		if (OpenURLBase)
			URL_OpenA((STRPTR)url, NULL);
	}
	#endif
}

void gui_cert_verify(struct browser_window *bw, struct hlcache_handle *c, const struct ssl_cert_info *certs, unsigned long num)
{
}