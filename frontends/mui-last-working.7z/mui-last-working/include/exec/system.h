#if defined(__MORPHOS__)
#include_next <exec/system.h>
#endif
