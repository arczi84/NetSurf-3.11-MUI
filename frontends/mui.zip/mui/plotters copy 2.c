/*
 * mui/plotters.c
 * NetSurf MUI render functions updated for new NetSurf API
 *
 * Copyright 2009 Ilkka Lehtoranta <ilkleht@isoveli.org>
 * Modifications 2025 by <Your Name> to update to new NetSurf API,
 * fix origin offset, unify font system, and correct color conversion.
 *
 * This file is part of NetSurf, http://www.netsurf-browser.org/
 *
 * NetSurf is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; version 2 of the License.
 *
 * NetSurf is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <cybergraphx/cybergraphics.h>
#include <intuition/intuition.h>
#include <graphics/rpattr.h>
#include <proto/cybergraphics.h>
#include <proto/graphics.h>
#include <proto/layers.h>
#undef NO_INLINE_STDARG
#include <proto/ttengine.h>
#include <proto/exec.h>
#include <math.h>

#include "mui/gui.h"
#include "mui/bitmap.h"
#include "mui/font.h"
#include "mui/plotters.h"
#include "mui/utils.h"
#include "utils/utf8.h"
#include "utils/log.h"
#include "utils/nsoption.h"
#include "netsurf/css.h"
#include "netsurf/plotters.h"

#include <ft2build.h>
#include <freetype/freetype.h>
#include <freetype/ftcache.h>
#include <freetype/ftglyph.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

#define MIN(a,b) (((a)<(b))?(a):(b))
#define MAX(a,b) (((a)>(b))?(a):(b))

/* The bitmap format is ABGR (0xAABBGGRR) */
#define ABGR_TO_ARGB(abgr) \
    (((abgr & 0x000000FF) << 16) /* R */ \
   | ((abgr & 0x0000FF00)      ) /* G */ \
   | ((abgr & 0x00FF0000) >> 16) /* B */)

#define BITMAP_FLAGS BMF_MINPLANES
#define PATT_DOT    0xAAAA
#define PATT_DASH   0xCCCC
#define PATT_LINE   0xFFFF

/* Keep the original global variables that other files expect */
struct RenderInfo renderinfo;
static LONG global_pen_a = -1, global_pen_b = -1;
static int origin_x = 0, origin_y = 0;
#define DX (origin_x)
#define DY (origin_y)
static ULONG last_fg_color = 0xFFFFFFFF;
static ULONG last_bg_color = 0xFFFFFFFF;
bool InitializePens(void);
BOOL fix_renderinfo_screen(void);
bool AllocateTextColorPens(void);

struct bez_point {
    float x;
    float y;
};

extern BOOL ft_text_render_bitmap(struct RastPort *rp,
    const char *string, size_t length,
    int x, int y, const struct css_style *style, colour fg);

/* Convert NetSurf ABGR -> Amiga RGB */
static ULONG ConvertNetSurfColor(colour ns)
{
    return ABGR_TO_ARGB(ns & 0x00FFFFFF);
}

/* Directly set foreground/background color */
static VOID SetRGBColor(struct RastPort *rp, ULONG rgb_color, BOOL is_background)
{
    if (!rp) return;
    UBYTE r = (rgb_color >> 16) & 0xFF;
    UBYTE g = (rgb_color >> 8) & 0xFF;
    UBYTE b = rgb_color & 0xFF;
    struct ViewPort *vp = renderinfo.screen ? &renderinfo.screen->ViewPort : NULL;
    LONG pen = is_background ? global_pen_b : global_pen_a;

    if (vp && vp->ColorMap) {
        ULONG r32 = r << 24;
        ULONG g32 = g << 24;
        ULONG b32 = b << 24;
        /* Obtain best pen without altering palette */
        LONG best = ObtainBestPen(vp->ColorMap,
                                  r32, g32, b32,
                                  OBP_Precision, PRECISION_GUI,
                                  TAG_DONE);
        if (best >= 0) {
            pen = best;
        }
    }

    if (is_background) {
        SetBPen(rp, pen);
    } else {
        SetAPen(rp, pen);
    }
}

/* Compatibility function for old API */
void SetColorAB(struct RastPort *rp, ULONG fg, ULONG bg)
{
    SetRGBColor(rp, fg, FALSE);
    SetRGBColor(rp, bg, TRUE);
}

static void mui_arc_gfxlib(struct RastPort *rp, int x, int y, int radius, int angle1, int angle2)
{
    float angle1_r = (float)(angle1) * (M_PI / 180.0);
    float angle2_r = (float)(angle2) * (M_PI / 180.0);
    float angle, b, c;
    float step = 0.1;
    int x0, y0, x1, y1;

    x0 = x;
    y0 = y;
    
    b = angle1_r;
    c = angle2_r;
    
    x1 = (int)(cos(b) * (float)radius);
    y1 = (int)(sin(b) * (float)radius);
    Move(rp, x0 + x1, y0 - y1);
        
    for (angle = (b + step); angle <= c; angle += step) {
        x1 = (int)(cos(angle) * (float)radius);
        y1 = (int)(sin(angle) * (float)radius);
        Draw(rp, x0 + x1, y0 - y1);
    }
}

static void mui_bezier(struct bez_point *restrict a, struct bez_point *restrict b,
                       struct bez_point *restrict c, struct bez_point *restrict d,
                       float t, struct bez_point *restrict p) 
{
    p->x = pow((1 - t), 3) * a->x + 3 * t * pow((1 - t), 2) * b->x + 
           3 * (1 - t) * pow(t, 2) * c->x + pow(t, 3) * d->x;
    p->y = pow((1 - t), 3) * a->y + 3 * t * pow((1 - t), 2) * b->y + 
           3 * (1 - t) * pow(t, 2) * c->y + pow(t, 3) * d->y;
}

/* Old API functions - kept for compatibility */
static bool mui_clear(colour c) { return true; }
static nserror mui_new_clip(const struct redraw_context *ctx, const struct rect *clip)
{
    LOG(("[mui_plotter] Entered mui_clip(%d, %d, %d, %d)", clip->x0, clip->y0, clip->x1, clip->y1));
    int x0 = clip->x0;
    int y0 = clip->y0;
    int x1 = clip->x1;
    int y1 = clip->y1;
    // Użyj RastPort z kontekstu!
    struct RastPort *rp = (struct RastPort *)ctx->priv;
    //struct RastPort *rp = (struct RastPort *)ctx->priv;

    if (!rp || !rp->Layer) {
        LOG(("[mui_plotter] mui_clip: Invalid RastPort or Layer"));
        return false;
    }

    LOG(("[mui_plotter] mui_clip: RastPort OK, creating Region"));
    
    static struct Rectangle R;
    struct Region *reg = InstallClipRegion(rp->Layer, NULL);
    
    LOG(("[mui_plotter] mui_clip: InstallClipRegion done, reg=%p", reg));
    
    if (!reg) {
        LOG(("[mui_plotter] mui_clip: Creating new region"));
        reg = NewRegion(); 
    } else {
        LOG(("[mui_plotter] mui_clip: Clearing existing region"));
        ClearRectRegion(reg, &R);
    }
    
    R.MinX = x0+DX; R.MinY = y0+DY;
    R.MaxX = x1-1+DX; R.MaxY = y1-1+DY;
    
    LOG(("[mui_plotter] mui_clip: Setting rectangle (%d,%d,%d,%d)", R.MinX, R.MinY, R.MaxX, R.MaxY));
    
    OrRectRegion(reg, &R);
    
    LOG(("[mui_plotter] mui_clip: OrRectRegion done"));
    
    reg = InstallClipRegion(rp->Layer, reg);
    
    LOG(("[mui_plotter] mui_clip: Second InstallClipRegion done"));
    
    if (reg) {
        LOG(("[mui_plotter] mui_clip: Disposing old region"));
        DisposeRegion(reg);
    }
    
    LOG(("[mui_plotter] mui_clip: SUCCESS - returning true"));
    return true;
}
/*
static bool mui_clip1(int x0, int y0, int x1, int y1)
{
    NSLOG(plot, DEEPDEBUG, "[mui_plotter] Entered mui_clip(%d, %d, %d, %d)", x0, y0, x1, y1);

    struct RastPort *rp = (struct RastPort *)ctx->priv;
    if (!rp || !rp->Layer) return false;
    static struct Rectangle R;
    struct Region *reg = InstallClipRegion(rp->Layer, NULL);
    if (!reg) reg = NewRegion(); else ClearRectRegion(reg, &R);
    R.MinX = x0+DX; R.MinY = y0+DY;
    R.MaxX = x1-1+DX; R.MaxY = y1-1+DY;
    OrRectRegion(reg, &R);
    reg = InstallClipRegion(rp->Layer, reg);
    if (reg) DisposeRegion(reg);
    return true;
}
*/
static bool mui_fill(int x0, int y0, int x1, int y1, colour col)
{
    NSLOG(plot, DEEPDEBUG, "[mui_plotter] Entered mui_fill()");

    struct RastPort *rp = (struct RastPort *)ctx->priv;
    if (!rp) return false;
    x0+=DX; y0+=DY; x1+=DX; y1+=DY;
    ULONG pixel = ConvertNetSurfColor(col);
    ULONG depth = GetBitMapAttr(rp->BitMap, BMA_DEPTH);
    if (depth>8 && CyberGfxBase) {
        if (FillPixelArray(rp, x0, y0, x1-x0, y1-y0, pixel)==-1) {
            SetRGBColor(rp,pixel,FALSE);
            RectFill(rp,x0,y0,x1-1,y1-1);
        }
    } else {
        SetRGBColor(rp,pixel,FALSE);
        RectFill(rp,x0,y0,x1-1,y1-1);
    }
    return true;
}

static bool mui_old_rectangle(int x0,int y0,int w,int h,int lw,colour col,bool dot,bool dash)
{
    struct RastPort *rp = (struct RastPort *)ctx->priv; if(!rp) return false;
    x0+=DX; y0+=DY;
    ULONG pixel = ConvertNetSurfColor(col);
    ULONG depth = GetBitMapAttr(rp->BitMap,BMA_DEPTH);
    if(depth>8&&CyberGfxBase) {
        FillPixelArray(rp,x0,y0,lw,h,pixel);
        FillPixelArray(rp,x0+w-lw,y0,lw,h,pixel);
        FillPixelArray(rp,x0,y0,w,lw,pixel);
        FillPixelArray(rp,x0,y0+h-lw,w,lw,pixel);
    } else {
        LONG oldP=rp->LinePtrn; UBYTE oldW=rp->PenWidth;
        rp->LinePtrn = dot?PATT_DOT:(dash?PATT_DASH:PATT_LINE);
        rp->PenWidth=rp->PenHeight=lw;
        SetRGBColor(rp,pixel,FALSE);
        Move(rp,x0,y0); Draw(rp,x0+w-1,y0); Draw(rp,x0+w-1,y0+h-1);
        Draw(rp,x0,y0+h-1); Draw(rp,x0,y0);
        rp->LinePtrn=oldP; rp->PenWidth=rp->PenHeight=oldW;
    }
    return true;
}

static bool mui_old_line(int x0,int y0,int x1,int y1,int lw,colour col,bool dot,bool dash)
{
    struct RastPort *rp=renderinfo.rp; if(!rp) return false;
    x0+=DX; y0+=DY; x1+=DX; y1+=DY;
    ULONG pixel=ConvertNetSurfColor(col);
    LONG oldP=rp->LinePtrn; UBYTE oldW=rp->PenWidth;
    rp->LinePtrn = dot?PATT_DOT:(dash?PATT_DASH:PATT_LINE);
    rp->PenWidth=rp->PenHeight=lw;
    SetRGBColor(rp,pixel,FALSE);
    Move(rp,x0,y0); Draw(rp,x1,y1);
    rp->LinePtrn=oldP; rp->PenWidth=rp->PenHeight=oldW;
    return true;
}

static bool mui_old_polygon(int *pts,unsigned n,colour fill)
{
    struct RastPort *rp=renderinfo.rp; if(!rp||n<3) return false;
    ULONG pixel=ConvertNetSurfColor(fill);
    ULONG depth=GetBitMapAttr(rp->BitMap,BMA_DEPTH);
    if(depth>8&&CyberGfxBase&&n==4) {
        int minx=pts[0],maxx=pts[0],miny=pts[1],maxy=pts[1];
        for(int i=1;i<4;i++){minx=MIN(minx,pts[2*i]);maxx=MAX(maxx,pts[2*i]);miny=MIN(miny,pts[2*i+1]);maxy=MAX(maxy,pts[2*i+1]);}
        FillPixelArray(rp,minx+DX,miny+DY,maxx-minx,maxy-miny,pixel);
        return true;
    }
    SetRGBColor(rp,pixel,FALSE);
    struct AreaInfo A; struct TmpRas T; UBYTE buf[512];
    InitArea(&A,buf,sizeof(buf)/5);
    InitTmpRas(&T,AllocMem(renderinfo.width*renderinfo.height,MEMF_FAST),renderinfo.width);
    rp->AreaInfo=&A; rp->TmpRas=&T;
    AreaMove(rp,pts[0]+DX,pts[1]+DY);
    for(unsigned i=1;i<n;i++) AreaDraw(rp,pts[2*i]+DX,pts[2*i+1]+DY);
    AreaEnd(rp);
    rp->AreaInfo=NULL; rp->TmpRas=NULL;
    FreeMem(T.RasPtr,renderinfo.width*renderinfo.height);
    return true;
}

static bool mui_old_disc(int x,int y,int r,colour col,bool fill) {return false;}
static bool mui_old_arc(int x,int y,int r,int a1,int a2,colour col) {return false;}

static bool mui_old_bitmap(int x,int y,int width,int height,struct bitmap *bm,colour bg,struct content *content)
{
    if(width&&height&&bm) {
        struct BitMap *src=bm->bitmap;
        if(!src) {src=AllocBitMap(bm->width,bm->height,32,BITMAP_FLAGS,renderinfo.rp->BitMap);bm->bitmap=src;bm->update=1;}
        if(bm->update) {struct RastPort trp;InitRastPort(&trp);trp.BitMap=src;
            WritePixelArray(bm->pixdata,0,0,bm->modulo,&trp,0,0,bm->width,bm->height,RECTFMT_RGBA);
            bm->update=0;
        }
        BltBitMapRastPort(src,0,0,renderinfo.rp,x+DX,y+DY,width,height,0xc0);
        return true;
    }
    return false;
}

static bool mui_old_bitmap_tile(int x,int y,int width,int height,struct bitmap *bm,colour bg,bool repeat_x,bool repeat_y,struct content *content)
{
    if(!bm||!bm->bitmap) return false;
    int bx=bm->width,by=bm->height;
    for(int dx=0;dx<width;dx+=bx)
    for(int dy=0;dy<height;dy+=by)
        BltBitMapRastPort(bm->bitmap,0,0,renderinfo.rp,x+DX+dx,y+DY+dy,bx,by,0xc0);
    return true;
}

/* Text rendering */
static bool mui_old_text(int x,int y,const struct css_style *st,
    const char *txt,size_t len,colour bg,colour fg)
{
    struct RastPort *rp=renderinfo.rp;
    if(!rp||!txt||len==0) return false;
    APTR fn=mui_open_font(rp,st);
    if(!fn) return false;
    UBYTE oldDm=GetDrMd(rp); SetDrMd(rp,JAM1);
    ULONG pixel=ConvertNetSurfColor(fg);
    SetRGBColor(rp,pixel,FALSE);
    bool ok=false;

    // Simplified approach - just use basic text rendering
    if(rp->Font) {
        int by=y+DY+rp->Font->tf_Baseline-13;
        Move(rp,x+DX,by); Text(rp,txt,len); ok=true;
    }

    SetDrMd(rp,oldDm);
    mui_close_font(rp,fn);
    return ok;
}

static nserror mui_group_start(const char *name)
{
    LOG(("[mui_plotter] Entered mui_group_start() "));

    origin_x = renderinfo.origin_x;
    origin_y = renderinfo.origin_y;
    if (!renderinfo.screen) fix_renderinfo_screen();
    LOG(("[mui_plotter] renderinfo.screen: %p", renderinfo.screen));
    InitializePens();
    LOG(("[mui_plotter] Pens initialized:"));
    AllocateTextColorPens();
    LOG(("[mui_plotter] before mui_clip()"));
   // return mui_clip(0, 0, renderinfo.width, renderinfo.height);
}

static nserror mui_group_end(void){return NSERROR_OK;}
static nserror mui_flush(void){return NSERROR_OK;}
static bool mui_old_path(float *pts,unsigned n,colour fill,float w,colour col,float *tr){return false;}

/* NEW API FUNCTIONS */

/**
 * \brief Sets a clip rectangle for subsequent plot operations.
 */
static nserror
mui_new_clip1(const struct redraw_context *ctx, const struct rect *clip)
{
    NSLOG(plot, DEEPDEBUG, "[mui_plotter] Entered mui_clip()");
    //return mui_clip(clip->x0, clip->y0, clip->x1, clip->y1) ? NSERROR_OK : NSERROR_INVALID;
}

/**
 * Plots an arc
 */
static nserror
mui_new_arc(const struct redraw_context *ctx,
        const plot_style_t *style,
        int x, int y, int radius, int angle1, int angle2)
{
    NSLOG(plot, DEEPDEBUG, "[mui_plotter] Entered mui_arc()");

    struct RastPort *rp = (struct RastPort *)ctx->priv;
    if (!rp) return NSERROR_INVALID;

    if (angle2 < angle1) {
        angle2 += 360;
    }

    ULONG pixel = ConvertNetSurfColor(style->fill_colour);
    SetRGBColor(rp, pixel, FALSE);
    mui_arc_gfxlib(rp, x + DX, y + DY, radius, angle1, angle2);

    return NSERROR_OK;
}

/**
 * Plots a circle
 */
static nserror
mui_new_disc(const struct redraw_context *ctx,
         const plot_style_t *style,
         int x, int y, int radius)
{
    NSLOG(plot, DEEPDEBUG, "[mui_plotter] Entered mui_disc()");

    struct RastPort *rp = (struct RastPort *)ctx->priv;
    if (!rp) return NSERROR_INVALID;
    
    x += DX;
    y += DY;

    if (style->fill_type != PLOT_OP_TYPE_NONE) {
        ULONG pixel = ConvertNetSurfColor(style->fill_colour);
        SetRGBColor(rp, pixel, FALSE);
        // Simple circle drawing without AreaCircle
        DrawEllipse(rp, x, y, radius, radius);
    }

    if (style->stroke_type != PLOT_OP_TYPE_NONE) {
        ULONG pixel = ConvertNetSurfColor(style->stroke_colour);
        SetRGBColor(rp, pixel, FALSE);
        DrawEllipse(rp, x, y, radius, radius);
    }

    return NSERROR_OK;
}

/**
 * Plots a line
 */
static nserror
mui_new_line(const struct redraw_context *ctx,
         const plot_style_t *style,
         const struct rect *line)
{
    NSLOG(plot, DEEPDEBUG, "[mui_plotter] Entered mui_line()");

    struct RastPort *rp = (struct RastPort *)ctx->priv;
    if (!rp) return NSERROR_INVALID;

    int x0 = line->x0 + DX;
    int y0 = line->y0 + DY;
    int x1 = line->x1 + DX;
    int y1 = line->y1 + DY;

    rp->PenWidth = plot_style_fixed_to_int(style->stroke_width);
    rp->PenHeight = plot_style_fixed_to_int(style->stroke_width);

    switch (style->stroke_type) {
        case PLOT_OP_TYPE_SOLID:
        default:
            rp->LinePtrn = PATT_LINE;
            break;

        case PLOT_OP_TYPE_DOT:
            rp->LinePtrn = PATT_DOT;
            break;

        case PLOT_OP_TYPE_DASH:
            rp->LinePtrn = PATT_DASH;
            break;
    }

    ULONG pixel = ConvertNetSurfColor(style->stroke_colour);
    SetRGBColor(rp, pixel, FALSE);
    Move(rp, x0, y0);
    Draw(rp, x1, y1);

    rp->PenWidth = 1;
    rp->PenHeight = 1;
    rp->LinePtrn = PATT_LINE;

    return NSERROR_OK;
}

/**
 * Plots a rectangle.
 */
static nserror
mui_new_rectangle(const struct redraw_context *ctx,
              const plot_style_t *style,
              const struct rect *rect)
{
    NSLOG(plot, DEEPDEBUG, "[mui_plotter] Entered mui_rectangle()");

    struct RastPort *rp = (struct RastPort *)ctx->priv;
    if (!rp) return NSERROR_INVALID;

    int x0 = rect->x0 + DX;
    int y0 = rect->y0 + DY;
    int x1 = rect->x1 + DX;
    int y1 = rect->y1 + DY;

    if (style->fill_type != PLOT_OP_TYPE_NONE) {
        ULONG pixel = ConvertNetSurfColor(style->fill_colour);
        ULONG depth = GetBitMapAttr(rp->BitMap, BMA_DEPTH);
        
        if (depth > 8 && CyberGfxBase) {
            if (FillPixelArray(rp, x0, y0, x1 - x0, y1 - y0, pixel) == -1) {
                SetRGBColor(rp, pixel, FALSE);
                RectFill(rp, x0, y0, x1 - 1, y1 - 1);
            }
        } else {
            SetRGBColor(rp, pixel, FALSE);
            RectFill(rp, x0, y0, x1 - 1, y1 - 1);
        }
    }

    if (style->stroke_type != PLOT_OP_TYPE_NONE) {
        rp->PenWidth = plot_style_fixed_to_int(style->stroke_width);
        rp->PenHeight = plot_style_fixed_to_int(style->stroke_width);

        switch (style->stroke_type) {
            case PLOT_OP_TYPE_SOLID:
            default:
                rp->LinePtrn = PATT_LINE;
                break;

            case PLOT_OP_TYPE_DOT:
                rp->LinePtrn = PATT_DOT;
                break;

            case PLOT_OP_TYPE_DASH:
                rp->LinePtrn = PATT_DASH;
                break;
        }

        ULONG pixel = ConvertNetSurfColor(style->stroke_colour);
        SetRGBColor(rp, pixel, FALSE);
        Move(rp, x0, y0);
        Draw(rp, x1, y0);
        Draw(rp, x1, y1);
        Draw(rp, x0, y1);
        Draw(rp, x0, y0);

        rp->PenWidth = 1;
        rp->PenHeight = 1;
        rp->LinePtrn = PATT_LINE;
    }

    return NSERROR_OK;
}

/**
 * Plot a polygon
 */
static nserror
mui_new_polygon(const struct redraw_context *ctx,
            const plot_style_t *style,
            const int *p,
            unsigned int n)
{
    NSLOG(plot, DEEPDEBUG, "[mui_plotter] Entered mui_polygon()");

    struct RastPort *rp = (struct RastPort *)ctx->priv;
    if (!rp || n < 3) return NSERROR_INVALID;

    ULONG pixel = ConvertNetSurfColor(style->fill_colour);
    SetRGBColor(rp, pixel, FALSE);

    struct AreaInfo A; 
    struct TmpRas T; 
    UBYTE buf[512];
    
    InitArea(&A, buf, sizeof(buf)/5);
    InitTmpRas(&T, AllocMem(renderinfo.width * renderinfo.height, MEMF_FAST), renderinfo.width);
    
    rp->AreaInfo = &A; 
    rp->TmpRas = &T;
    
    if (AreaMove(rp, p[0] + DX, p[1] + DY) == -1) {
        NSLOG(netsurf, INFO, "AreaMove: vector list full");
    }

    for (uint32_t k = 1; k < n; k++) {
        if (AreaDraw(rp, p[k*2] + DX, p[(k*2)+1] + DY) == -1) {
            NSLOG(netsurf, INFO, "AreaDraw: vector list full");
        }
    }

    if (AreaEnd(rp) == -1) {
        NSLOG(netsurf, INFO, "AreaEnd: error");
    }

    rp->AreaInfo = NULL; 
    rp->TmpRas = NULL;
    FreeMem(T.RasPtr, renderinfo.width * renderinfo.height);

    return NSERROR_OK;
}

/**
 * Plots a path.
 */
static nserror
mui_new_path(const struct redraw_context *ctx,
         const plot_style_t *pstyle,
         const float *p,
         unsigned int n,
         const float transform[6])
{
    unsigned int i;
    struct bez_point start_p = {0, 0}, cur_p = {0, 0}, p_a, p_b, p_c, p_r;

    NSLOG(plot, DEEPDEBUG, "[mui_plotter] Entered mui_path()");

    struct RastPort *rp = (struct RastPort *)ctx->priv;
    if (!rp || n == 0) return NSERROR_INVALID;

    if (p[0] != PLOTTER_PATH_MOVE) {
        NSLOG(netsurf, INFO, "Path does not start with move");
        return NSERROR_INVALID;
    }

    if (pstyle->fill_colour != NS_TRANSPARENT) {
        ULONG pixel = ConvertNetSurfColor(pstyle->fill_colour);
        SetRGBColor(rp, pixel, FALSE);
        if (pstyle->stroke_colour != NS_TRANSPARENT) {
            ULONG stroke_pixel = ConvertNetSurfColor(pstyle->stroke_colour);
            SetRGBColor(rp, stroke_pixel, TRUE);
        }
    } else {
        if (pstyle->stroke_colour != NS_TRANSPARENT) {
            ULONG pixel = ConvertNetSurfColor(pstyle->stroke_colour);
            SetRGBColor(rp, pixel, FALSE);
        } else {
            return NSERROR_OK;
        }
    }

    /* Construct path */
    for (i = 0; i < n; ) {
        if (p[i] == PLOTTER_PATH_MOVE) {
            if (pstyle->fill_colour != NS_TRANSPARENT) {
                // Area functions not available, use simple move
                Move(rp, p[i+1] + DX, p[i+2] + DY);
            } else {
                Move(rp, p[i+1] + DX, p[i+2] + DY);
            }
            start_p.x = p[i+1];
            start_p.y = p[i+2];
            cur_p.x = start_p.x;
            cur_p.y = start_p.y;
            i += 3;
        } else if (p[i] == PLOTTER_PATH_CLOSE) {
            Draw(rp, start_p.x + DX, start_p.y + DY);
            i++;
        } else if (p[i] == PLOTTER_PATH_LINE) {
            Draw(rp, p[i+1] + DX, p[i+2] + DY);
            cur_p.x = p[i+1];
            cur_p.y = p[i+2];
            i += 3;
        } else if (p[i] == PLOTTER_PATH_BEZIER) {
            p_a.x = p[i+1];
            p_a.y = p[i+2];
            p_b.x = p[i+3];
            p_b.y = p[i+4];
            p_c.x = p[i+5];
            p_c.y = p[i+6];

            for (float t = 0.0; t <= 1.0; t += 0.1) {
                mui_bezier(&cur_p, &p_a, &p_b, &p_c, t, &p_r);
                Draw(rp, p_r.x + DX, p_r.y + DY);
            }
            cur_p.x = p_c.x;
            cur_p.y = p_c.y;
            i += 7;
        } else {
            NSLOG(netsurf, INFO, "bad path command %f", p[i]);
            return NSERROR_INVALID;
        }
    }

    return NSERROR_OK;
}

/**
 * Plot a bitmap
 */
static nserror
mui_new_bitmap_tile(const struct redraw_context *ctx,
                struct bitmap *bitmap,
                int x, int y,
                int width,
                int height,
                colour bg,
                bitmap_flags_t flags)
{
    struct RastPort *rp = (struct RastPort *)ctx->priv;
    if (!rp) return NSERROR_INVALID;

    bool repeat_x = (flags & BITMAPF_REPEAT_X);
    bool repeat_y = (flags & BITMAPF_REPEAT_Y);

    NSLOG(plot, DEEPDEBUG, "[mui_plotter] Entered mui_bitmap_tile()");

    if ((width == 0) || (height == 0)) {
        return NSERROR_OK;
    }

    x += DX;
    y += DY;

    if (!bitmap) {
        return NSERROR_OK;
    }

    /* Simple bitmap rendering - use the existing bitmap structure */
    struct BitMap *src = bitmap->bitmap;
    if (!src) {
        src = AllocBitMap(bitmap->width, bitmap->height, 32, BITMAP_FLAGS, rp->BitMap);
        bitmap->bitmap = src;
        bitmap->update = 1;
    }
    
    if (bitmap->update) {
        struct RastPort trp;
        InitRastPort(&trp);
        trp.BitMap = src;
        WritePixelArray(bitmap->pixdata, 0, 0, bitmap->modulo, &trp, 0, 0, 
                       bitmap->width, bitmap->height, RECTFMT_RGBA);
        bitmap->update = 0;
    }

    if (!(repeat_x || repeat_y)) {
        /* Simple case - single bitmap */
        BltBitMapRastPort(src, 0, 0, rp, x, y, width, height, 0xc0);
    } else {
        /* Tiling case */
        int bx = bitmap->width;
        int by = bitmap->height;
        
        for (int dx = 0; dx < width; dx += bx) {
            for (int dy = 0; dy < height; dy += by) {
                BltBitMapRastPort(src, 0, 0, rp, x + dx, y + dy, bx, by, 0xc0);
            }
        }
    }

    return NSERROR_OK;
}

/**
 * Text plotting.
 */
static nserror
mui_new_text(const struct redraw_context *ctx,
         const struct plot_font_style *fstyle,
         int x,
         int y,
         const char *text,
         size_t length)
{
    NSLOG(plot, DEEPDEBUG, "[mui_plotter] Entered mui_text()");

    struct RastPort *rp = (struct RastPort *)ctx->priv;
    if (!rp || !text || length == 0) return NSERROR_OK;

    x += DX;
    y += DY;

    /* Set text color */
    ULONG pixel = ConvertNetSurfColor(fstyle->foreground);
    SetRGBColor(rp, pixel, FALSE);
    
    UBYTE oldDm = GetDrMd(rp);
    SetDrMd(rp, JAM1);

    /* Simple text rendering using system font */
    if (rp->Font) {
        /* Calculate baseline position */
        int baseline_offset = rp->Font->tf_Baseline;
        if (baseline_offset <= 0) {
            /* Estimate baseline if not available */
            baseline_offset = (rp->Font->tf_YSize * 3) / 4;
        }
        
        int by = y + baseline_offset;
        Move(rp, x, by);
        Text(rp, text, length);
    }
    
    SetDrMd(rp, oldDm);
    
    return NSERROR_OK;
}

bool InitializePens(void)
{
    LOG(("[mui_plotter] InitializePens() START"));
    
    if(!renderinfo.screen||!renderinfo.screen->ViewPort.ColorMap) {
        LOG(("[mui_plotter] No screen or colormap, using defaults"));
        global_pen_a=1;
        global_pen_b=0;
        return true;
    }
    
    LOG(("[mui_plotter] Screen and ColorMap available"));
    struct ColorMap *cm=renderinfo.screen->ViewPort.ColorMap;
    LOG(("[mui_plotter] ColorMap: %p", cm));
    
    if(global_pen_a<0) {
        LOG(("[mui_plotter] Obtaining pen A"));
        global_pen_a=ObtainPen(cm,-1,0,0,0,PEN_EXCLUSIVE);
        LOG(("[mui_plotter] Pen A obtained: %d", global_pen_a));
    }
    
    if(global_pen_b<0) {
        LOG(("[mui_plotter] Obtaining pen B"));
        global_pen_b=ObtainPen(cm,-1,0,0,0,PEN_EXCLUSIVE);
        LOG(("[mui_plotter] Pen B obtained: %d", global_pen_b));
    }
    
    if(global_pen_a<0) global_pen_a=1;
    if(global_pen_b<0) global_pen_b=0;
    
    LOG(("[mui_plotter] InitializePens() END - pens: A=%d, B=%d", global_pen_a, global_pen_b));
    return true;
}

bool AllocateTextColorPens(void)
{
    LOG(("[mui_plotter] AllocateTextColorPens() START"));
    
    if(!renderinfo.screen||!renderinfo.screen->ViewPort.ColorMap) {
        LOG(("[mui_plotter] No screen or colormap in AllocateTextColorPens"));
        return false;
    }
    
    LOG(("[mui_plotter] Getting ColorMap"));
    struct ColorMap *cm=renderinfo.screen->ViewPort.ColorMap;
    
    LOG(("[mui_plotter] ObtainBestPen for white"));
    global_pen_a=ObtainBestPen(cm,0xFFFFFFFF,0,0,OBP_Precision,PRECISION_GUI,TAG_DONE);
    LOG(("[mui_plotter] White pen: %d", global_pen_a));
    
    LOG(("[mui_plotter] ObtainBestPen for black"));
    global_pen_b=ObtainBestPen(cm,0,0,0,OBP_Precision,PRECISION_GUI,TAG_DONE);
    LOG(("[mui_plotter] Black pen: %d", global_pen_b));
    
    LOG(("[mui_plotter] AllocateTextColorPens() END"));
    return (global_pen_a>=0&&global_pen_b>=0);
}

void FreeTextColorPens(void)
{
    if(!renderinfo.screen||!renderinfo.screen->ViewPort.ColorMap) return;
    struct ColorMap *cm=renderinfo.screen->ViewPort.ColorMap;
    if(global_pen_a>=0) ReleasePen(cm,global_pen_a);
    if(global_pen_b>=0) ReleasePen(cm,global_pen_b);
    global_pen_a=global_pen_b=-1;
}

/* Debug renderinfo and screen fallback */
void debug_renderinfo_init(void)
{
    LOG(("=== RENDERINFO DEBUG ==="));
    LOG(("renderinfo.rp = %p", renderinfo.rp));
    LOG(("renderinfo.screen = %p", renderinfo.screen));
    LOG(("renderinfo.width = %d", renderinfo.width));
    LOG(("renderinfo.height = %d", renderinfo.height));
    LOG(("renderinfo.origin_x = %d", renderinfo.origin_x));
    LOG(("renderinfo.origin_y = %d", renderinfo.origin_y));
}

BOOL fix_renderinfo_screen(void)
{
    LOG(("[mui_plotter] Entered fix_renderinfo_screen()"));
    if (renderinfo.screen) return TRUE;
    if (renderinfo.rp && renderinfo.rp->Layer) {
        /* TODO: extract screen from layer/window via MUI */
    }
    struct Screen *wb = LockPubScreen("Workbench");
    if (wb) { renderinfo.screen = wb; return TRUE; }
    return FALSE;
}

/* Global variables that other files expect */
//struct plotter_table plot;
static nserror mui_new_flush(const struct redraw_context *ctx)
{
    return NSERROR_OK;
}

static nserror mui_new_group_start(const struct redraw_context *ctx, const char *name)
{
    return mui_group_start(name) ? NSERROR_OK : NSERROR_INVALID;
}

static nserror mui_new_group_end(const struct redraw_context *ctx)
{
    return mui_group_end() ? NSERROR_OK : NSERROR_INVALID;
}

/* OLD API plotter table - kept for backward compatibility */
/*const struct plotter_table muiplot_old = {
    mui_clear, mui_old_rectangle, mui_old_line, mui_old_polygon,
    mui_fill, mui_clip, mui_old_text, mui_old_disc,
    mui_old_arc, mui_old_bitmap, mui_old_bitmap_tile,
    mui_group_start, mui_group_end, mui_flush, mui_old_path, false
};*/

/* NEW API plotter table */
const struct plotter_table muiplot = {
    .rectangle = mui_new_rectangle,
    .line = mui_new_line,
    .polygon = mui_new_polygon,
    .clip = mui_new_clip,
    .text = mui_new_text,
    .disc = mui_new_disc,
    .arc = mui_new_arc,
    .bitmap = mui_new_bitmap_tile,
    .path = mui_new_path,
    .flush = mui_flush,
    .fill =  mui_fill,           // ← DODAJ
    //.group_start = mui_group_start, // ← DODAJ  
    //.group_end = mui_group_end,     // ← DODAJ
    .option_knockout = true,
};