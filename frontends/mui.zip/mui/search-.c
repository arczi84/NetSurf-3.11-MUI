/*
 * Copyright 2004 John M Bell <jmb202@ecs.soton.ac.uk>
 * Copyright 2005 Adrian Lees <adrianl@users.sourceforge.net>
 * Copyright 2009 Mark Benjamin <netsurf-browser.org.MarkBenjamin@dfgh.net>
 *
 * This file is part of NetSurf, http://www.netsurf-browser.org/
 *
 * NetSurf is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; version 2 of the License.
 *
 * NetSurf is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * \file
 * Free text search (implementation)
 */

#include <ctype.h>
#include <string.h>

#include <proto/exec.h>
#include <proto/intuition.h>

#include "utils/errors.h"
#include "utils/log.h"
#include "utils/messages.h"
#include "utils/utils.h"
#include "utils/config.h"
#include "content/content.h"
#include "content/hlcache.h"
#undef m_len // Avoid conflict with AmigaOS m_len macro
#include "content/textsearch.h"
#include "netsurf/browser.h"
#include "netsurf/types.h"
#include "netsurf/browser_window.h"

#include "desktop/browser_private.h"
#include "desktop/search.h"
#include "desktop/selection.h"
#include "mui/gui.h"
#include "mui/methodstack.h"
#include "mui/mui.h"
#include "html/box.h"
#include "html/html.h"

#ifndef NOF_ELEMENTS
#define NOF_ELEMENTS(array) (sizeof(array)/sizeof(*(array)))
#endif

struct search_context {
	struct gui_window *window;
	struct hlcache_handle *content;
	struct textsearch_context *textsearch;
	char *search_string;
	search_flags_t flags;
	bool active;
	bool found;
};

static struct search_context *current_search = NULL;

/**
 * Callback for when search completes
 */
static void search_complete_callback(void *context)
{
	struct search_context *search = (struct search_context *)context;
	
	if (search && search->window) {
		/* Update GUI state based on search results */
		methodstack_push(search->window->win, 3, MM_FindText_DisableButtons,
			FALSE, FALSE);
	}
}

/**
 * Callback for when search finds a match
 */
static void search_found_callback(void *context, unsigned start_idx, unsigned end_idx)
{
	struct search_context *search = (struct search_context *)context;
	
	if (search) {
		search->found = true;
		if (search->window) {
			/* Scroll to show the found text */
			struct rect bounds;
			struct content *c = hlcache_handle_get_content(search->content);
			
			if (c && content_get_type(c) == CONTENT_HTML) {
				/* For HTML content, we need to get coordinates from the content */
				html_get_selection_dimensions(c, start_idx, end_idx, &bounds);
			} else {
				/* For text content */
				textplain_coords_from_range(c, start_idx, end_idx, &bounds);
			}
			
			gui_window_scroll_visible(search->window,
				bounds.x0, bounds.y0, bounds.x1, bounds.y1);
		}
	}
}

/**
 * Create a new search context
 */
static struct search_context *search_create_context(struct gui_window *window)
{
	struct search_context *search;
	
	search = calloc(1, sizeof(struct search_context));
	if (!search) {
		return NULL;
	}
	
	search->window = window;
	search->content = NULL;
	search->textsearch = NULL;
	search->search_string = NULL;
	search->flags = SEARCH_FLAG_NONE;
	search->active = false;
	search->found = false;
	
	return search;
}

/**
 * Destroy a search context
 */
static void search_destroy_context(struct search_context *search)
{
	if (!search) {
		return;
	}
	
	if (search->textsearch) {
		content_textsearch_destroy(search->textsearch);
	}
	
	if (search->search_string) {
		free(search->search_string);
	}
	
	free(search);
}

/**
 * Clear current search
 */
static void search_clear_current(void)
{
	if (current_search) {
		if (current_search->content) {
			content_textsearch_clear(current_search->content);
		}
		search_destroy_context(current_search);
		current_search = NULL;
	}
}

/**
 * Change the displayed search status.
 *
 * \param found  search pattern matched in text
 */
static void show_status(bool found)
{
	#warning implement me
#if 0
	ro_gui_set_icon_string(dialog_search, ICON_SEARCH_STATUS,
			found ? "" : messages_get("NotFound"), true);
#endif
}

/**
 * Determines whether any portion of the given text box should be
 * selected because it matches the current search string.
 *
 * \param  g             gui window
 * \param  start_offset  byte offset within text of string to be checked
 * \param  end_offset    byte offset within text
 * \param  start_idx     byte offset within string of highlight start
 * \param  end_idx       byte offset of highlight end
 * \return true iff part of the box should be highlighted
 */
bool gui_search_term_highlighted(struct gui_window *g, unsigned start_offset,
	unsigned end_offset, unsigned *start_idx, unsigned *end_idx)
{
	if (!current_search || !current_search->textsearch || 
	    current_search->window != g) {
		return false;
	}
	
	return content_textsearch_ishighlighted(current_search->textsearch,
		start_offset, end_offset, start_idx, end_idx);
}

/**
 * Begins/continues the search process
 * Note that this may be called many times for a single search.
 *
 * \param  forwards        search forwards from start/current position
 * \param  case_sensitive  perform case sensitive search
 * \param  string          search string
 * \param  window          gui window to search in
 */
void start_search(bool forwards, bool case_sensitive, const char *string,
	struct gui_window *window)
{
	nserror error;
	search_flags_t flags = SEARCH_FLAG_NONE;
	size_t string_len;
	size_t i;
	bool new_search = false;
	
	if (!window || !window->bw || !window->bw->current_content) {
		return;
	}
	
	NSLOG(netsurf, INFO, "start_search(%s)", string);
	
	string_len = strlen(string);
	
	/* Check if string contains only wildcards */
	for (i = 0; i < string_len; i++) {
		if (string[i] != '#' && string[i] != '*') {
			break;
		}
	}
	
	if (i >= string_len) {
		/* Empty or wildcard-only search - clear everything */
		search_clear_current();
		show_status(true);
		methodstack_push(window->win, 3, MM_FindText_DisableButtons, TRUE, TRUE);
		gui_window_set_scroll(window, 0, 0);
		return;
	}
	
	/* Set up search flags */
	if (case_sensitive) {
		flags |= SEARCH_FLAG_CASE_SENSITIVE;
	}
	if (forwards) {
		flags |= SEARCH_FLAG_FORWARDS;
	}
	if (current_search && current_search->search_string &&
	    strcmp(string, current_search->search_string) == 0 &&
	    current_search->flags == flags &&
	    current_search->content == window->bw->current_content) {
		/* Continue existing search */
		flags |= SEARCH_FLAG_SHOWALL;
	} else {
		/* New search */
		search_clear_current();
		new_search = true;
	}
	
	/* Create new search context if needed */
	if (!current_search) {
		current_search = search_create_context(window);
		if (!current_search) {
			NSLOG(netsurf, ERROR, "Failed to create search context");
			return;
		}
	}
	
	/* Update search context */
	current_search->window = window;
	current_search->content = window->bw->current_content;
	current_search->flags = flags;
	current_search->found = false;
	
	if (new_search || !current_search->search_string ||
	    strcmp(string, current_search->search_string) != 0) {
		if (current_search->search_string) {
			free(current_search->search_string);
		}
		current_search->search_string = strdup(string);
		if (!current_search->search_string) {
			NSLOG(netsurf, ERROR, "Failed to duplicate search string");
			search_clear_current();
			return;
		}
	}
	
	/* Perform the search */
	error = content_textsearch(current_search->content, current_search,
		flags, string);
	
	if (error != NSERROR_OK) {
		NSLOG(netsurf, ERROR, "Search failed: %s", messages_get_errorcode(error));
		search_clear_current();
		show_status(false);
		methodstack_push(window->win, 3, MM_FindText_DisableButtons, TRUE, TRUE);
		return;
	}
	
	current_search->active = true;
	show_status(current_search->found);
	
	/* Update button states - will be refined by search callbacks */
	methodstack_push(window->win, 3, MM_FindText_DisableButtons, FALSE, FALSE);
}

/**
 * Stop the current search and clear highlighting
 */
void search_stop(struct gui_window *window)
{
	if (current_search && current_search->window == window) {
		search_clear_current();
	}
	
	show_status(true);
	methodstack_push(window->win, 3, MM_FindText_DisableButtons, TRUE, TRUE);
}

/**
 * Search for next occurrence
 */
void search_next(struct gui_window *window)
{
	if (!current_search || current_search->window != window ||
	    !current_search->search_string) {
		return;
	}
	
	start_search(true, current_search->flags & SEARCH_FLAG_CASE_SENSITIVE,
		current_search->search_string, window);
}

/**
 * Search for previous occurrence
 */
void search_previous(struct gui_window *window)
{
	if (!current_search || current_search->window != window ||
	    !current_search->search_string) {
		return;
	}
	
	start_search(false, current_search->flags & SEARCH_FLAG_CASE_SENSITIVE,
		current_search->search_string, window);
}

/**
 * Show all search matches
 */
void search_show_all(struct gui_window *window, bool show_all)
{
	if (!current_search || current_search->window != window ||
	    !current_search->search_string) {
		return;
	}
	
	search_flags_t flags = current_search->flags;
	if (show_all) {
		flags |= SEARCH_FLAG_SHOWALL;
	} else {
		flags &= ~SEARCH_FLAG_SHOWALL;
	}
	
	content_textsearch(current_search->content, current_search,
		flags, current_search->search_string);
}

/**
 * Clean up when window is destroyed
 */
void search_window_destroy(struct gui_window *window)
{
	if (current_search && current_search->window == window) {
		search_clear_current();
	}
}
