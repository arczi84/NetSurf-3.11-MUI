#ifndef __SELECT_H__
#define __SELECT_H__

#include <proto/socket.h>

#endif /* __SELECT_H__ */
