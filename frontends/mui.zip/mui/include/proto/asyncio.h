#ifndef PROTO_ASYNCIO_H
#define PROTO_ASYNCIO_H
#include <exec/types.h>
#define ASIO_SHARED_LIB
extern struct Library *AsyncIOBase;
#include <clib/asyncio_protos.h>
#include <pragmas/asyncio_pragmas.h>
#endif
