/* $VER: proto/alib.h 1.0 (17.4.93) */
#ifndef ALIB_PROTO_H
#define ALIB_PROTO_H 1
#include <pragmas/config.h>
#include <exec/types.h>
#include <clib/alib_protos.h>
#endif
