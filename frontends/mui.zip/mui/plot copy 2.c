/* Enhanced color handling functions for MUI plotters */
/* Lepsze debugowanie kolorów */
/* NEW API plotter table */

bool plot_initiated = false;
void debug_screen_capabilities(void);

static ULONG ConvertNetSurfColor(colour ns)
{
    if (!plot_initiated)
	 //   mui_plotters_init();
    plot_initiated = true;

    ULONG result = ABGR_TO_ARGB(ns & 0x00FFFFFF);
    
    /* Debug log dla sprawdzenia konwersji kolorów */
    LOG(("ConvertNetSurfColor: input=0x%08lX, output=0x%08lX (R=%d G=%d B=%d)", 
         ns, result, 
         (result >> 16) & 0xFF, 
         (result >> 8) & 0xFF, 
         result & 0xFF));
    
    return result;
}

/* Alternatywna funkcja dla RTG bez konwersji */
static ULONG GetDirectPixel(colour ns)
{
    /* NetSurf używa formatu ABGR, RTG oczekuje RGB */
    UBYTE a = (ns >> 24) & 0xFF;
    UBYTE b = (ns >> 16) & 0xFF; 
    UBYTE g = (ns >> 8) & 0xFF;
    UBYTE r = ns & 0xFF;
    
    /* Zwróć w formacie RGB dla CyberGraphX */
    return (r << 16) | (g << 8) | b;
}

/* Initialize pen allocation */
bool InitializePens(void)
{
    if (!renderinfo.screen || !renderinfo.screen->ViewPort.ColorMap) {
        global_pen_a = 1;
        global_pen_b = 0;
        return true;
    }
    
    struct ColorMap *cm = renderinfo.screen->ViewPort.ColorMap;
    if (global_pen_a < 0) {
        global_pen_a = ObtainPen(cm, -1, 0, 0, 0, PEN_EXCLUSIVE);
    }
    if (global_pen_b < 0) {
        global_pen_b = ObtainPen(cm, -1, 0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF, PEN_EXCLUSIVE);
    }
    
    if (global_pen_a < 0) global_pen_a = 1;
    if (global_pen_b < 0) global_pen_b = 0;
    
    return true;
}
static BOOL screen_initialized = FALSE;

/* Funkcja do lazy-loading ekranu */
static BOOL ensure_screen_available(struct RastPort *rp)
{
    if (renderinfo.screen && screen_initialized) {
        return TRUE; /* Już mamy ekran */
    }
    
    LOG(("ensure_screen_available: Trying to get screen from RastPort"));
    
    /* Spróbuj pobrać ekran z RastPort */
    if (rp && rp->Layer && rp->Layer->rp) {
        struct Layer *layer = rp->Layer;
        
        /* Spróbuj różne metody pobrania ekranu */
        
        /* Metoda 1: Jeśli to jest layer okna */
        if (layer->Window) {
            renderinfo.screen = layer->Window;
            LOG(("Got screen from Window: %p", renderinfo.screen));
        }
        
        /* Metoda 2: Spróbuj przez viewport */
        if (!renderinfo.screen && rp->BitMap) {
            struct BitMap *bm = rp->BitMap;
            /* W AmigaOS 3.x, możemy spróbować znaleźć ekran przez bitmap */
            /* To jest hack, ale czasem działa */
            struct Screen *scr = LockPubScreen(NULL); /* Default public screen */
            if (scr) {
                renderinfo.screen = scr;
                UnlockPubScreen(NULL, scr);
                LOG(("Got default public screen: %p", renderinfo.screen));
            }
        }
        
        /* Metoda 3: Workbench screen jako ostateczny fallback */
        if (!renderinfo.screen) {
            renderinfo.screen = LockPubScreen("Workbench");
            if (renderinfo.screen) {
                LOG(("Got Workbench screen: %p", renderinfo.screen));
                /* NIE rób UnlockPubScreen tutaj - zachowaj referencję */
            }
        }
    }
    
    if (renderinfo.screen) {
        screen_initialized = TRUE;
        LOG(("Screen initialized successfully"));
        debug_screen_capabilities();
        return TRUE;
    }
    
    LOG(("ERROR: Could not get screen"));
    return FALSE;
}

/* Ulepszona funkcja SetRGBColor z lazy screen loading */
static VOID SetRGBColor(struct RastPort *rp, ULONG rgb_color, BOOL is_background)
{
    if (!rp) return;
    
    UBYTE r = (rgb_color >> 16) & 0xFF;
    UBYTE g = (rgb_color >> 8) & 0xFF;
    UBYTE b = rgb_color & 0xFF;
    
    /* Cache check */
    ULONG *last_color = is_background ? &last_bg_color : &last_fg_color;
    if (*last_color == rgb_color) {
        return;
    }
    *last_color = rgb_color;
    
    /* Spróbuj zainicjalizować ekran jeśli jeszcze nie mamy */
    if (!screen_initialized) {
        ensure_screen_available(rp);
    }
    
    ULONG depth = GetBitMapAttr(rp->BitMap, BMA_DEPTH);
    
    LOG(("SetRGBColor: color=0x%08lX, depth=%lu, r=%d g=%d b=%d, screen=%p", 
         rgb_color, depth, r, g, b, renderinfo.screen));
    
    /* Jeśli mamy ekran i głębokość > 8, spróbuj ObtainBestPen */
    if (renderinfo.screen && renderinfo.screen->ViewPort.ColorMap && depth > 8) {
        struct ViewPort *vp = &renderinfo.screen->ViewPort;
        ULONG r32 = (ULONG)r << 24;
        ULONG g32 = (ULONG)g << 24;
        ULONG b32 = (ULONG)b << 24;
        
        LOG(("Trying ObtainBestPen with r32=0x%08lX g32=0x%08lX b32=0x%08lX", r32, g32, b32));
        
        LONG pen = ObtainBestPen(vp->ColorMap,
                                 r32, g32, b32,
                                 OBP_Precision, PRECISION_GUI,
                                 TAG_DONE);
        
        if (pen >= 0) {
            LOG(("SetRGBColor: Using ObtainBestPen pen %ld for color 0x%08lX", pen, rgb_color));
            if (is_background) {
                SetBPen(rp, pen);
            } else {
                SetAPen(rp, pen);
            }
            ReleasePen(vp->ColorMap, pen);
            return;
        } else {
            LOG(("ObtainBestPen failed, error=%ld", pen));
        }
    }
    
    /* Fallback do statycznych penów 0-4 */
    LOG(("SetRGBColor: Using fallback pen logic"));
    
    LONG pen;
    if (rgb_color == 0x00000000) {
        pen = 0; /* Black */
    } else if (rgb_color == 0x00FFFFFF) {
        pen = 1; /* White */
    } else if (r > 200 && g < 100 && b < 100) {
        pen = 2; /* Red */
    } else if (r < 100 && g > 200 && b < 100) {
        pen = 3; /* Green */
    } else if (r < 100 && g < 100 && b > 200) {
        pen = 4; /* Blue */
    } else {
        /* Use intensity for other colors */
        ULONG intensity = (r + g + b);
        pen = (intensity > 384) ? 1 : 0;
    }
    
    LOG(("SetRGBColor: Fallback pen %ld for color 0x%08lX", pen, rgb_color));
    
    if (is_background) {
        SetBPen(rp, pen);
    } else {
        SetAPen(rp, pen);
    }
}

/* Enhanced color setting with proper RGB handling */
static VOID SetRGBColor4(struct RastPort *rp, ULONG rgb_color, BOOL is_background)
{
    if (!rp) return;
    
    UBYTE r = (rgb_color >> 16) & 0xFF;
    UBYTE g = (rgb_color >> 8) & 0xFF;
    UBYTE b = rgb_color & 0xFF;
    
    /* Cache check to avoid unnecessary pen operations */
    ULONG *last_color = is_background ? &last_bg_color : &last_fg_color;
    if (*last_color == rgb_color) {
        return; /* Color already set */
    }
    *last_color = rgb_color;
    
    struct ViewPort *vp = renderinfo.screen ? &renderinfo.screen->ViewPort : NULL;
    ULONG depth = GetBitMapAttr(rp->BitMap, BMA_DEPTH);
    
    LOG(("SetRGBColor: color=0x%08lX, depth=%lu, r=%d g=%d b=%d", 
         rgb_color, depth, r, g, b));
    
    /* For RTG screens with > 8 bit depth, use direct colors */
    if (depth >= 15 && CyberGfxBase && vp && vp->ColorMap) {
        ULONG r32 = (ULONG)r << 24;
        ULONG g32 = (ULONG)g << 24;
        ULONG b32 = (ULONG)b << 24;
        
        /* Get pen for this specific color */
        LONG pen = ObtainBestPen(vp->ColorMap,
                                 r32, g32, b32,
                                 OBP_Precision, PRECISION_GUI,
                                 TAG_DONE);
        
        if (pen >= 0) {
            LOG(("SetRGBColor: Using RTG pen %ld for color 0x%08lX", pen, rgb_color));
            if (is_background) {
                SetBPen(rp, pen);
            } else {
                SetAPen(rp, pen);
            }
            /* Important: Release the pen after setting it */
            ReleasePen(vp->ColorMap, pen);
            return;
        }
        LOG(("SetRGBColor: ObtainBestPen failed, falling back"));
    }
    
    /* For palette modes or RTG fallback */
    if (vp && vp->ColorMap) {
        ULONG r32 = (ULONG)r << 24;
        ULONG g32 = (ULONG)g << 24;  
        ULONG b32 = (ULONG)b << 24;
        
        LONG pen = ObtainBestPen(vp->ColorMap,
                                r32, g32, b32,
                                OBP_Precision, PRECISION_IMAGE,
                                TAG_DONE);
        
        if (pen >= 0) {
            LOG(("SetRGBColor: Using palette pen %ld for color 0x%08lX", pen, rgb_color));
            if (is_background) {
                SetBPen(rp, pen);
            } else {
                SetAPen(rp, pen);
            }
            ReleasePen(vp->ColorMap, pen);
            return;
        }
        LOG(("SetRGBColor: Palette ObtainBestPen also failed"));
    }
    
    LOG(("SetRGBColor: Using fallback pen logic"));
    
    /* Ultimate fallback - but improve the logic */
    LONG pen;
    if (rgb_color == 0x00000000) {
        pen = 0; /* Black */
    } else if (rgb_color == 0x00FFFFFF) {
        pen = 1; /* White */
    } else if (r > 200 && g < 100 && b < 100) {
        pen = 2; /* Try red if available */
    } else if (r < 100 && g > 200 && b < 100) {
        pen = 3; /* Try green if available */
    } else if (r < 100 && g < 100 && b > 200) {
        pen = 4; /* Try blue if available */
    } else {
        /* Use intensity for other colors */
        ULONG intensity = (r + g + b);
        pen = (intensity > 384) ? 1 : 0;
    }
    
    LOG(("SetRGBColor: Fallback pen %ld for color 0x%08lX", pen, rgb_color));
    
    if (is_background) {
        SetBPen(rp, pen);
    } else {
        SetAPen(rp, pen);
    }
}

/* Enhanced rectangle function with direct pixel support */
nserror
mui_rectangle(const struct redraw_context *ctx,
              const plot_style_t *style,
              const struct rect *rect)
{
    struct RastPort *rp = (struct RastPort *)ctx->priv;
    if (!rp) return NSERROR_INVALID;

    /* Handle fill (background) */
    if (style->fill_type != PLOT_OP_TYPE_NONE) {
        ULONG pixel = ConvertNetSurfColor(style->fill_colour);
        ULONG depth = GetBitMapAttr(rp->BitMap, BMA_DEPTH);
        
        /* For RTG screens, try direct pixel writing first */
        if (depth >= 15 && CyberGfxBase) {
            LONG result = FillPixelArray(rp, rect->x0, rect->y0, 
                                        rect->x1 - rect->x0, rect->y1 - rect->y0, pixel);
            
            if (result != -1) {
                /* Direct pixel write successful */
                goto handle_stroke;
            }
            /* If FillPixelArray failed, fall through to pen method */
        }
        
        /* Pen-based filling for palette modes or RTG fallback */
        SetRGBColor(rp, pixel, FALSE);
        RectFill(rp, rect->x0, rect->y0, rect->x1 - 1, rect->y1 - 1);
    }

handle_stroke:
    /* Handle stroke (border) */
    if (style->stroke_type != PLOT_OP_TYPE_NONE) {
        LONG oldPenWidth = rp->PenWidth;
        LONG oldPenHeight = rp->PenHeight;
        UWORD oldLinePtrn = rp->LinePtrn;
        
        rp->PenWidth = MAX(1, plot_style_fixed_to_int(style->stroke_width));
        rp->PenHeight = MAX(1, plot_style_fixed_to_int(style->stroke_width));

        switch (style->stroke_type) {
            case PLOT_OP_TYPE_SOLID:
            default:
                rp->LinePtrn = PATT_LINE;
                break;
            case PLOT_OP_TYPE_DOT:
                rp->LinePtrn = PATT_DOT;
                break;
            case PLOT_OP_TYPE_DASH:
                rp->LinePtrn = PATT_DASH;
                break;
        }

        ULONG pixel = ConvertNetSurfColor(style->stroke_colour);
        SetRGBColor(rp, pixel, FALSE);
        
        Move(rp, rect->x0, rect->y0);
        Draw(rp, rect->x1 - 1, rect->y0);
        Draw(rp, rect->x1 - 1, rect->y1 - 1);
        Draw(rp, rect->x0, rect->y1 - 1);
        Draw(rp, rect->x0, rect->y0);

        /* Restore pen settings */
        rp->PenWidth = oldPenWidth;
        rp->PenHeight = oldPenHeight;
        rp->LinePtrn = oldLinePtrn;
    }

    return NSERROR_OK;
}
static nserror
mui_rectangle3(const struct redraw_context *ctx,
                     const plot_style_t *style,
                     const struct rect *rect)
{
    struct RastPort *rp = (struct RastPort *)ctx->priv;
    if (!rp) return NSERROR_INVALID;

    /* Handle fill (background) with direct pixel writing */
    if (style->fill_type != PLOT_OP_TYPE_NONE) {
        ULONG pixel = ConvertNetSurfColor(style->fill_colour);
        ULONG depth = GetBitMapAttr(rp->BitMap, BMA_DEPTH);
        
        LOG(("mui_rectangle_direct: fill_colour=0x%08lX, pixel=0x%08lX, depth=%lu", 
             style->fill_colour, pixel, depth));
        
        /* For RTG screens, try direct pixel writing first */
        if (depth >= 15 && CyberGfxBase) {
            LONG result = FillPixelArray(rp, rect->x0, rect->y0, 
                                        rect->x1 - rect->x0, rect->y1 - rect->y0, pixel);
            
            LOG(("FillPixelArray result: %ld", result));
            
            if (result != -1) {
                LOG(("Direct pixel fill successful!"));
                goto handle_stroke;
            }
            LOG(("FillPixelArray failed, using pen method"));
        }
        
        /* Pen-based filling as fallback */
        SetRGBColor(rp, pixel, FALSE);
        RectFill(rp, rect->x0, rect->y0, rect->x1 - 1, rect->y1 - 1);
    }

handle_stroke:
    /* Handle stroke normally */
    if (style->stroke_type != PLOT_OP_TYPE_NONE) {
        ULONG pixel = ConvertNetSurfColor(style->stroke_colour);
        SetRGBColor(rp, pixel, FALSE);
        
        /* Draw rectangle border */
        Move(rp, rect->x0, rect->y0);
        Draw(rp, rect->x1 - 1, rect->y0);
        Draw(rp, rect->x1 - 1, rect->y1 - 1);
        Draw(rp, rect->x0, rect->y1 - 1);
        Draw(rp, rect->x0, rect->y0);
    }

    return NSERROR_OK;
}

/* Debug function to check screen capabilities */
void debug_screen_capabilities(void)
{
    if (!renderinfo.screen) {
        LOG(("DEBUG: No screen available!"));
        return;
    }
    
    struct ViewPort *vp = &renderinfo.screen->ViewPort;
    ULONG depth = GetBitMapAttr(renderinfo.rp->BitMap, BMA_DEPTH);
    
    LOG(("=== SCREEN CAPABILITIES ==="));
    LOG(("Screen: %p", renderinfo.screen));
    LOG(("ViewPort: %p", vp));
    LOG(("ColorMap: %p", vp ? vp->ColorMap : NULL));
    LOG(("BitMap depth: %lu", depth));
    LOG(("CyberGfxBase: %p", CyberGfxBase));
    
    if (vp && vp->ColorMap) {
        LOG(("ColorMap Count: %d", vp->ColorMap->Count));
        LOG(("ColorMap Type: %d", vp->ColorMap->Type));
        
        /* Test if we can obtain some basic pens */
        LONG red_pen = ObtainBestPen(vp->ColorMap, 0xFF000000, 0, 0, TAG_DONE);
        LONG green_pen = ObtainBestPen(vp->ColorMap, 0, 0xFF000000, 0, TAG_DONE);
        LONG blue_pen = ObtainBestPen(vp->ColorMap, 0, 0, 0xFF000000, TAG_DONE);
        
        LOG(("Test pens - Red: %ld, Green: %ld, Blue: %ld", red_pen, green_pen, blue_pen));
        
        if (red_pen >= 0) ReleasePen(vp->ColorMap, red_pen);
        if (green_pen >= 0) ReleasePen(vp->ColorMap, green_pen);
        if (blue_pen >= 0) ReleasePen(vp->ColorMap, blue_pen);
    }
    
    LOG(("=== END CAPABILITIES ==="));
}

/* Initialize with debug */
nserror mui_plotters_init(void)
{
    /* Initialize global variables */
    last_fg_color = 0xFFFFFFFF;
    last_bg_color = 0xFFFFFFFF;
    global_pen_a = -1;
    global_pen_b = -1;
    
    /* Debug screen capabilities */
    debug_screen_capabilities();
    
    /* Initialize pens */
    InitializePens();
    
    return NSERROR_OK;
}

/* Enhanced text function with background color support */
nserror
mui_text(const struct redraw_context *ctx,
         const struct plot_font_style *fstyle,
         int x,
         int y,
         const char *text,
         size_t length)
{
    struct RastPort *rp = (struct RastPort *)ctx->priv;
    if (!rp || !text || length == 0) return NSERROR_OK;
    
    /* Open appropriate font */
    APTR font_node = mui_open_font(rp, fstyle);
    if (!font_node) {
        LOG(("WARNING: No font available, using default"));
        /* Fallback rendering with color support */
        ULONG pixel = ConvertNetSurfColor(fstyle->foreground);
        SetRGBColor(rp, pixel, FALSE);
        
        /* Handle background color if specified */
        if (fstyle->background != NS_TRANSPARENT) {
            ULONG bg_pixel = ConvertNetSurfColor(fstyle->background);
            SetRGBColor(rp, bg_pixel, TRUE);
            SetDrMd(rp, JAM2); /* Use both foreground and background */
        } else {
            SetDrMd(rp, JAM1); /* Use only foreground */
        }
        
        int baseline_y = y + (rp->Font ? rp->Font->tf_Baseline : 12) - 13;
        Move(rp, x, baseline_y);
        Text(rp, text, length);
        
        SetDrMd(rp, JAM1); /* Reset to default */
        return NSERROR_OK;
    }
    
    struct fontnode *node = (struct fontnode *)font_node;
    UBYTE oldDm = GetDrMd(rp);
    
    /* Set up drawing mode based on background */
    if (fstyle->background != NS_TRANSPARENT) {
        ULONG bg_pixel = ConvertNetSurfColor(fstyle->background);
        SetRGBColor(rp, bg_pixel, TRUE);
        SetDrMd(rp, JAM2); /* Use both foreground and background */
    } else {
        SetDrMd(rp, JAM1); /* Use only foreground */
    }
    
    /* Set foreground color */
    ULONG pixel = ConvertNetSurfColor(fstyle->foreground);
    SetRGBColor(rp, pixel, FALSE);
    
    bool ok = false;
    
    /* Try system font rendering */
    if (!ok && node->sysfont) {
        const char *render_text = text;
        char *converted_text = NULL;
        size_t render_length = length;
        
        /* Convert UTF-8 if needed */
        if (needs_character_conversion()) {
            converted_text = AllocVec(length * 2 + 1, MEMF_ANY);
            if (converted_text) {
                render_length = convert_utf8_to_iso8859_2(text, length, 
                                                         converted_text, length * 2 + 1);
                render_text = converted_text;
            }
        }
        
        int baseline_y = y + node->sysfont->tf_Baseline - 11;
        Move(rp, x, baseline_y);
        Text(rp, render_text, render_length);
        
        if (converted_text) {
            FreeVec(converted_text);
        }
        ok = true;
    }
    
    /* Fallback to default font */
    if (!ok && rp->Font) {
        int baseline_y = y + rp->Font->tf_Baseline - 13;
        Move(rp, x, baseline_y);
        Text(rp, text, length);
        ok = true;
    }
    
    /* Restore drawing mode */
    SetDrMd(rp, oldDm);
    
    /* Close font */
    mui_close_font(rp, font_node);
    
    return ok ? NSERROR_OK : NSERROR_INVALID;
}



/* Cleanup function */
void mui_plotters_fini(void)
{
    if (renderinfo.screen && renderinfo.screen->ViewPort.ColorMap) {
        struct ColorMap *cm = renderinfo.screen->ViewPort.ColorMap;
        if (global_pen_a >= 0) {
            ReleasePen(cm, global_pen_a);
            global_pen_a = -1;
        }
        if (global_pen_b >= 0) {
            ReleasePen(cm, global_pen_b);
            global_pen_b = -1;
        }
    }
}
